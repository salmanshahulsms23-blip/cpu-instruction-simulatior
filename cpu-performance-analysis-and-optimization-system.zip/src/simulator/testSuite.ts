/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VerificationTest } from '../types/riscv.ts';
import { detectBottlenecks } from './bottlenecks.ts';
import { generateOptimizations } from './optimizer.ts';
import { parseAssembly } from './parser.ts';
import { simulatePipeline } from './pipeline.ts';

export function runAllVerificationTests(): {
  total: number;
  passed: number;
  failed: number;
  results: { test: VerificationTest; pass: boolean; details: string; expected: any; actual: any }[];
} {
  const tests: VerificationTest[] = [
    // 1. Instruction Validation
    {
      id: 'test-parser-valid',
      name: 'Instruction Parser: R-Type and I-Type Syntax',
      category: 'PARSER',
      description: 'Parses standard RISC-V instructions (add, addi, lw, sw) and verifies decoded register fields.',
      run: () => {
        const code = `addi t0, zero, 42\nadd t1, t0, t0\nlw t2, 4(s0)\nsw t2, 8(s0)`;
        const res = parseAssembly(code);
        const pass = res.errors.length === 0 && res.instructions.length === 4 &&
          res.instructions[0].rd === 'x5' && res.instructions[0].imm === 42 &&
          res.instructions[1].rs1 === 'x5' && res.instructions[1].rs2 === 'x5';
        return {
          pass,
          details: pass ? 'All 4 instructions parsed accurately with correct registers and immediates' : `Errors: ${res.errors.join(', ')}`,
          expected: '4 instructions, 0 errors, rd=x5, imm=42',
          actual: `${res.instructions.length} instructions, ${res.errors.length} errors`,
        };
      },
    },
    {
      id: 'test-parser-error-handling',
      name: 'Instruction Parser: Syntax Error Diagnostics',
      category: 'PARSER',
      description: 'Detects invalid instructions and missing operands, reporting line numbers accurately.',
      run: () => {
        const invalidCode = `addi t0, zero\nunknown_op t1, t2\nadd t1, t2, x99`;
        const res = parseAssembly(invalidCode);
        const pass = res.errors.length >= 2;
        return {
          pass,
          details: pass ? `Successfully caught ${res.errors.length} syntax/register errors` : 'Failed to catch syntax errors',
          expected: 'At least 2 validation errors',
          actual: `${res.errors.length} errors detected`,
        };
      },
    },

    // 2. Register Dependencies & RAW Detection
    {
      id: 'test-raw-hazard-detection',
      name: 'RAW Hazard Detection: Producer-Consumer Distance',
      category: 'DEPENDENCY',
      description: 'Identifies Read-After-Write hazards between dependent register pairs.',
      run: () => {
        const code = `addi t0, zero, 10\nadd t1, t0, t0`;
        const { instructions } = parseAssembly(code);
        const sim = simulatePipeline(instructions, false);
        const bottlenecks = detectBottlenecks(instructions, sim);
        const rawFound = bottlenecks.some(b => b.type === 'RAW_HAZARD');
        return {
          pass: rawFound,
          details: rawFound ? 'Detected RAW hazard on register t0 between instructions 1 and 2' : 'Failed to detect RAW hazard',
          expected: 'RAW_HAZARD bottleneck reported',
          actual: rawFound ? 'RAW_HAZARD detected' : 'None detected',
        };
      },
    },

    // 3. Pipeline Stall Calculation WITHOUT Forwarding
    {
      id: 'test-stall-without-forwarding',
      name: 'Pipeline Stalls: ALU-to-ALU RAW Without Forwarding',
      category: 'PIPELINE',
      description: 'Verifies that a back-to-back ALU dependency produces exactly 2 stall cycles without forwarding.',
      run: () => {
        const code = `addi t0, zero, 5\nadd t1, t0, t0`;
        const { instructions } = parseAssembly(code);
        const sim = simulatePipeline(instructions, false);
        // Ideal 2 instructions = 6 cycles (5 + 2 - 1). With 2 stalls, total cycles = 8.
        const pass = sim.stallCycles === 2 && sim.totalCycles === 8;
        return {
          pass,
          details: pass ? `Accurately calculated 2 stall cycles (total = 8 cycles)` : `Stall cycles = ${sim.stallCycles}, total = ${sim.totalCycles}`,
          expected: 'stallCycles = 2, totalCycles = 8',
          actual: `stallCycles = ${sim.stallCycles}, totalCycles = ${sim.totalCycles}`,
        };
      },
    },

    // 4. Pipeline Execution WITH Forwarding (0 stalls for ALU-to-ALU)
    {
      id: 'test-forwarding-alu-to-alu',
      name: 'Pipeline Execution: Forwarding ALU-to-ALU (0 Stalls)',
      category: 'PIPELINE',
      description: 'Verifies that EX/MEM-to-EX hardware forwarding reduces ALU-to-ALU stall cycles to exactly zero.',
      run: () => {
        const code = `addi t0, zero, 5\nadd t1, t0, t0`;
        const { instructions } = parseAssembly(code);
        const sim = simulatePipeline(instructions, true);
        // 2 instructions ideal = 5 + 2 - 1 = 6 cycles, 0 stalls
        const pass = sim.stallCycles === 0 && sim.totalCycles === 6;
        return {
          pass,
          details: pass ? `Forwarding eliminated all stalls (0 stalls, total = 6 cycles)` : `Stalls: ${sim.stallCycles}`,
          expected: 'stallCycles = 0, totalCycles = 6',
          actual: `stallCycles = ${sim.stallCycles}, totalCycles = ${sim.totalCycles}`,
        };
      },
    },

    // 5. Load-Use Hazard Stall (1 stall cycle even WITH forwarding)
    {
      id: 'test-load-use-stall',
      name: 'Pipeline Stalls: Load-Use Hazard With Forwarding (1 Stall)',
      category: 'PIPELINE',
      description: 'Verifies that a load instruction immediately followed by an ALU consumer produces exactly 1 stall cycle with forwarding.',
      run: () => {
        const code = `lw t0, 0(s0)\nadd t1, t0, s1`;
        const { instructions } = parseAssembly(code);
        const sim = simulatePipeline(instructions, true);
        // 2 instructions = 6 cycles ideal + 1 stall = 7 cycles
        const pass = sim.stallCycles === 1 && sim.totalCycles === 7;
        return {
          pass,
          details: pass ? `Load-Use hazard correctly produced 1 stall bubble (total = 7 cycles)` : `Stalls: ${sim.stallCycles}`,
          expected: 'stallCycles = 1, totalCycles = 7',
          actual: `stallCycles = ${sim.stallCycles}, totalCycles = ${sim.totalCycles}`,
        };
      },
    },

    // 6. Metrics Calculation (CPI & IPC formulas)
    {
      id: 'test-metrics-calculation',
      name: 'Performance Metrics: CPI and IPC Verification',
      category: 'METRICS',
      description: 'Verifies mathematical accuracy of CPI = Cycles / Instructions and IPC = 1 / CPI.',
      run: () => {
        const code = `addi t0, zero, 1\naddi t1, zero, 2\naddi t2, zero, 3`;
        const { instructions } = parseAssembly(code);
        const sim = simulatePipeline(instructions, true);
        // 3 independent instructions = 5 + 3 - 1 = 7 cycles. CPI = 7 / 3 = 2.333. IPC = 3 / 7 = 0.429.
        const expectedCPI = parseFloat((sim.totalCycles / sim.instructionCount).toFixed(3));
        const expectedIPC = parseFloat((sim.instructionCount / sim.totalCycles).toFixed(3));
        const pass = sim.cpi === expectedCPI && sim.ipc === expectedIPC;
        return {
          pass,
          details: pass ? `CPI (${sim.cpi}) and IPC (${sim.ipc}) match exact mathematical definitions` : 'Formula mismatch',
          expected: `CPI = ${expectedCPI}, IPC = ${expectedIPC}`,
          actual: `CPI = ${sim.cpi}, IPC = ${sim.ipc}`,
        };
      },
    },

    // 7. Optimization Semantic Correctness & Stall Reduction
    {
      id: 'test-optimization-scheduling',
      name: 'Optimization Engine: Instruction Scheduling & Correctness',
      category: 'OPTIMIZATION',
      description: 'Tests that hoisting independent instructions into the load-use delay slot reduces cycles while maintaining identical register values.',
      run: () => {
        const code = `lw t0, 0(s0)\nadd t1, t0, zero\naddi t2, zero, 100`;
        const { instructions } = parseAssembly(code);
        const opt = generateOptimizations(instructions, true, 1000);
        const pass = opt.comparison.isImprovement && opt.isSemanticallyEqual;
        return {
          pass,
          details: pass
            ? `Cycles reduced from ${opt.comparison.originalCycles} to ${opt.comparison.optimizedCycles} (${opt.comparison.cycleReductionPct}% speedup). Register equivalence: 100% verified.`
            : `Failed: improvement=${opt.comparison.isImprovement}, semanticEqual=${opt.isSemanticallyEqual}`,
          expected: 'cycle reduction > 0% and 100% semantic register match',
          actual: `reduction = ${opt.comparison.cycleReductionPct}%, semanticMatch = ${opt.isSemanticallyEqual}`,
        };
      },
    },
  ];

  const results = tests.map(test => {
    const outcome = test.run();
    return {
      test,
      pass: outcome.pass,
      details: outcome.details,
      expected: outcome.expected,
      actual: outcome.actual,
    };
  });

  const passed = results.filter(r => r.pass).length;
  const failed = results.length - passed;

  return {
    total: tests.length,
    passed,
    failed,
    results,
  };
}

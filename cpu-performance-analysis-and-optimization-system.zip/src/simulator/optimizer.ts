/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComparisonMetrics,
  OptimizationRecommendation,
  RiscvInstruction,
  SimulationResult,
} from '../types/riscv.ts';
import { parseAssembly } from './parser.ts';
import { simulatePipeline } from './pipeline.ts';

export interface OptimizationAnalysis {
  recommendations: OptimizationRecommendation[];
  optimizedAssembly: string;
  comparison: ComparisonMetrics;
  isSemanticallyEqual: boolean;
  semanticDifferences: string[];
}

export function generateOptimizations(
  instructions: RiscvInstruction[],
  forwardingEnabled: boolean,
  clockFrequencyMHz: number
): OptimizationAnalysis {
  const recommendations: OptimizationRecommendation[] = [];
  const loadOps = ['lw', 'lh', 'lb', 'lbu', 'lhu'];

  // Clone instructions to work on
  let transformed: RiscvInstruction[] = instructions.map(i => ({ ...i }));
  let changed = false;

  // --- Step 1: Remove Redundant Identity Operations (e.g. addi x, x, 0) ---
  const filteredInstructions: RiscvInstruction[] = [];
  for (let i = 0; i < transformed.length; i++) {
    const cur = transformed[i];
    if (cur.mnemonic === 'addi' && cur.rd === cur.rs1 && cur.imm === 0 && cur.rd !== 'x0') {
      recommendations.push({
        id: `opt-dead-${cur.id}`,
        title: `Eliminate Redundant Operation: '${cur.originalText}'`,
        category: 'REDUNDANCY_REMOVAL',
        description: `Removed instruction ${cur.id} ('${cur.originalText}'). Adding 0 to register ${cur.rd} produces no architectural state change.`,
        rationale: `Saves 1 instruction fetch and execution cycle with zero effect on computation.`,
        confidence: 'guaranteed_safe',
        suggestedAssembly: `# Removed redundant '${cur.originalText}'`,
        estimatedStallReduction: 1,
      });
      changed = true;
    } else {
      filteredInstructions.push(cur);
    }
  }
  transformed = filteredInstructions;

  // --- Step 2: Instruction Scheduling / Reordering for Load-Use Latency ---
  // Look for: [Load instr] -> [Dependent instr] -> [Independent instr]
  // We can hoist [Independent instr] into the delay slot between Load and Dependent!
  for (let i = 0; i < transformed.length - 2; i++) {
    const loadInstr = transformed[i];
    const depInstr = transformed[i + 1];
    const candidate = transformed[i + 2];

    if (loadOps.includes(loadInstr.mnemonic) && loadInstr.rd) {
      const isDep = depInstr.rs1 === loadInstr.rd || depInstr.rs2 === loadInstr.rd;
      if (isDep) {
        // Verify safety of swapping candidate with depInstr:
        // Candidate must not read what load writes
        const candidateReads = [candidate.rs1, candidate.rs2].filter(Boolean);
        const candidateWrites = candidate.rd;

        const readsLoadTarget = candidateReads.includes(loadInstr.rd);
        const writesLoadTarget = candidateWrites === loadInstr.rd;

        // Candidate must not have dependencies with depInstr
        const candidateReadsDepTarget = depInstr.rd && candidateReads.includes(depInstr.rd);
        const candidateWritesDepRead = candidateWrites && [depInstr.rs1, depInstr.rs2].includes(candidateWrites);
        const candidateWritesDepTarget = depInstr.rd && candidateWrites === depInstr.rd;

        // Candidate must not be control flow
        const isBranchOrJump = ['beq', 'bne', 'blt', 'bge', 'jal', 'jalr'].includes(candidate.mnemonic);

        if (
          !readsLoadTarget &&
          !writesLoadTarget &&
          !candidateReadsDepTarget &&
          !candidateWritesDepRead &&
          !candidateWritesDepTarget &&
          !isBranchOrJump
        ) {
          // SWAP candidate into position i + 1 (delay slot)
          transformed[i + 1] = candidate;
          transformed[i + 2] = depInstr;
          changed = true;

          recommendations.push({
            id: `opt-reorder-${loadInstr.id}-${candidate.id}`,
            title: `Instruction Scheduling: Hoist '${candidate.originalText}'`,
            category: 'REORDERING',
            description: `Hoisted independent instruction '${candidate.originalText}' immediately after load instruction '${loadInstr.originalText}', ahead of dependent '${depInstr.originalText}'.`,
            rationale: `In a 5-stage pipeline with forwarding, data loaded from memory is only ready at the end of the MEM stage. By placing independent work in the delay slot, the CPU executes useful work while memory is being accessed, completely eliminating 1 stall bubble.`,
            confidence: 'guaranteed_safe',
            suggestedAssembly: `${loadInstr.originalText}\n${candidate.originalText}  # Scheduled in delay slot\n${depInstr.originalText}`,
            estimatedStallReduction: 1,
          });
          break; // apply one scheduling pass
        }
      }
    }
  }

  // --- Step 3: Non-Forwarding Reordering (ALU RAW Hazard Delay Filling) ---
  if (!forwardingEnabled) {
    for (let i = 0; i < transformed.length - 2; i++) {
      const prod = transformed[i];
      const cons = transformed[i + 1];
      const indep = transformed[i + 2];

      if (prod.rd && (cons.rs1 === prod.rd || cons.rs2 === prod.rd)) {
        const indepReads = [indep.rs1, indep.rs2].filter(Boolean);
        const indepWrites = indep.rd;
        const noProdConflict = !indepReads.includes(prod.rd) && indepWrites !== prod.rd;
        const noConsConflict = !(cons.rd && indepReads.includes(cons.rd)) && !(indepWrites && [cons.rs1, cons.rs2].includes(indepWrites));
        const notBranch = !['beq', 'bne', 'blt', 'bge', 'jal'].includes(indep.mnemonic);

        if (noProdConflict && noConsConflict && notBranch) {
          transformed[i + 1] = indep;
          transformed[i + 2] = cons;
          changed = true;

          recommendations.push({
            id: `opt-nofwd-sched-${prod.id}-${indep.id}`,
            title: `ALU RAW Hazard Separation for '${cons.originalText}'`,
            category: 'STALL_REDUCTION',
            description: `Inserted independent instruction '${indep.originalText}' between producer '${prod.originalText}' and consumer '${cons.originalText}'.`,
            rationale: `Without forwarding hardware, dependent instructions must wait for WB writeback. Increasing the instruction distance reduces stall penalties.`,
            confidence: 'guaranteed_safe',
            suggestedAssembly: `${prod.originalText}\n${indep.originalText}  # Separates RAW pair\n${cons.originalText}`,
            estimatedStallReduction: 1,
          });
          break;
        }
      }
    }
  }

  // Re-generate assembly code string
  const optimizedLines = transformed.map(instr => {
    return instr.originalText;
  });
  const optimizedAssembly = optimizedLines.join('\n');

  // Simulate original program
  const originalResult = simulatePipeline(instructions, forwardingEnabled, clockFrequencyMHz, 'Original Program');

  // Parse and simulate optimized program
  const { instructions: parsedOptimized } = parseAssembly(optimizedAssembly);
  const optimizedResult = simulatePipeline(parsedOptimized, forwardingEnabled, clockFrequencyMHz, 'Optimized Program');

  // Verify semantic equivalence of register state
  const semanticDifferences: string[] = [];
  let isSemanticallyEqual = true;

  for (let r = 0; r < 32; r++) {
    const regName = `x${r}`;
    const origVal = originalResult.finalRegisters[regName] || 0;
    const optVal = optimizedResult.finalRegisters[regName] || 0;
    if (origVal !== optVal) {
      isSemanticallyEqual = false;
      semanticDifferences.push(`Register ${regName}: Original = ${origVal}, Optimized = ${optVal}`);
    }
  }

  // Comparison metrics
  const originalCycles = originalResult.totalCycles;
  const optimizedCycles = optimizedResult.totalCycles;
  const cycleReductionPct = originalCycles > 0
    ? parseFloat((((originalCycles - optimizedCycles) / originalCycles) * 100).toFixed(1))
    : 0;
  const isImprovement = optimizedCycles < originalCycles;

  let verdictExplanation = '';
  if (isImprovement) {
    verdictExplanation = `Optimization successful! Execution cycles decreased from ${originalCycles} to ${optimizedCycles} (${cycleReductionPct}% reduction). CPI improved from ${originalResult.cpi} to ${optimizedResult.cpi}. Architectural register correctness is 100% verified.`;
  } else if (optimizedCycles === originalCycles) {
    verdictExplanation = `No cycle reduction observed (${originalCycles} cycles). The original sequence was already close to optimal for this dependency graph, or remaining stalls are constrained by true data dependencies.`;
  } else {
    verdictExplanation = `Optimized sequence took ${optimizedCycles} cycles vs ${originalCycles} cycles originally. Reverting to original is recommended.`;
  }

  const comparison: ComparisonMetrics = {
    originalResult,
    optimizedResult,
    originalCycles,
    optimizedCycles,
    cycleReductionPct,
    originalCPI: originalResult.cpi,
    optimizedCPI: optimizedResult.cpi,
    originalStallCycles: originalResult.stallCycles,
    optimizedStallCycles: optimizedResult.stallCycles,
    isImprovement,
    verdictExplanation,
  };

  return {
    recommendations,
    optimizedAssembly,
    comparison,
    isSemanticallyEqual,
    semanticDifferences,
  };
}

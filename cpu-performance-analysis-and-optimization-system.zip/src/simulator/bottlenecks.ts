/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BottleneckItem, RiscvInstruction, SimulationResult } from '../types/riscv.ts';
import { X_TO_ABI } from './parser.ts';

export function detectBottlenecks(
  instructions: RiscvInstruction[],
  simResult: SimulationResult
): BottleneckItem[] {
  const bottlenecks: BottleneckItem[] = [];
  const loadOps = ['lw', 'lh', 'lb', 'lbu', 'lhu'];

  // 1. Analyze RAW Data Dependencies
  for (let i = 0; i < instructions.length; i++) {
    const producer = instructions[i];
    if (!producer.rd || producer.rd === 'x0') continue;

    // Check next 1-3 instructions for consumer
    for (let j = i + 1; j < Math.min(instructions.length, i + 4); j++) {
      const consumer = instructions[j];
      const distance = j - i;
      const readsRs1 = consumer.rs1 === producer.rd;
      const readsRs2 = consumer.rs2 === producer.rd;

      if (readsRs1 || readsRs2) {
        const regAbi = X_TO_ABI[producer.rd] || producer.rd;
        const isProducerLoad = loadOps.includes(producer.mnemonic);

        if (distance === 1 && isProducerLoad) {
          // Classic Load-Use Hazard
          bottlenecks.push({
            id: `load-use-${producer.id}-${consumer.id}`,
            type: 'LOAD_USE_HAZARD',
            severity: 'high',
            title: `Load-Use Hazard on ${regAbi}`,
            instructionsInvolved: [producer.id, consumer.id],
            technicalExplanation: `Instruction ${consumer.id} ('${consumer.originalText}') attempts to read register ${regAbi} in cycle ${consumer.id + 1} immediately after load instruction ${producer.id} ('${producer.originalText}'). Because data from memory is only available at the completion of the MEM stage, a 1-cycle pipeline bubble must be injected even when forwarding is enabled.`,
            beginnerExplanation: `Instruction ${consumer.id} needs the value loaded by Instruction ${producer.id}. Because reading data from RAM/Cache takes time, the CPU cannot calculate with that number on the very next beat. The pipeline has to pause for 1 idle cycle (a "bubble").`,
            impact: `Causes 1 guaranteed stall cycle in pipelined execution with forwarding (or 2 stall cycles without forwarding).`,
            improvementSuggestion: `Reorder independent instructions between the load and this dependent instruction to fill the delay slot without stalling.`,
            isSafeToApply: true,
          });
        } else if (!simResult.forwardingEnabled && distance <= 2) {
          // Non-forwarding RAW Stall
          const stallPenalty = distance === 1 ? 2 : 1;
          bottlenecks.push({
            id: `raw-nofwd-${producer.id}-${consumer.id}`,
            type: 'RAW_HAZARD',
            severity: 'high',
            title: `RAW Data Hazard (No Forwarding) on ${regAbi}`,
            instructionsInvolved: [producer.id, consumer.id],
            technicalExplanation: `Instruction ${consumer.id} ('${consumer.originalText}') reads register ${regAbi} which is computed by Instruction ${producer.id} ('${producer.originalText}'). Without hardware forwarding, register values are only written back in the WB stage, forcing ${stallPenalty} stall cycle(s).`,
            beginnerExplanation: `Without hardware shortcut wires (data forwarding), Instruction ${consumer.id} must wait for Instruction ${producer.id} to travel all the way through all 5 stages to the end before the register file is updated.`,
            impact: `Injects ${stallPenalty} stall cycle(s) into the pipeline.`,
            improvementSuggestion: `Enable hardware forwarding or schedule independent instructions between producer and consumer.`,
            isSafeToApply: true,
          });
        } else if (simResult.forwardingEnabled && !isProducerLoad && distance === 1) {
          // Forwarded ALU-ALU dependency (info)
          bottlenecks.push({
            id: `fwd-resolved-${producer.id}-${consumer.id}`,
            type: 'RAW_HAZARD',
            severity: 'info',
            title: `ALU-to-ALU RAW Dependency (Resolved via Forwarding)`,
            instructionsInvolved: [producer.id, consumer.id],
            technicalExplanation: `Instruction ${consumer.id} depends on ${regAbi} from Instruction ${producer.id}. The EX/MEM-to-EX forwarding multiplexer routes the result directly with 0 stall cycles.`,
            beginnerExplanation: `Instruction ${consumer.id} uses the answer from Instruction ${producer.id}. Thanks to hardware forwarding wires, the answer is passed directly across the chip with zero waiting time!`,
            impact: `0 stall cycles (fully mitigated by forwarding hardware).`,
            improvementSuggestion: `No change required; optimal hardware forwarding path active.`,
            isSafeToApply: false,
          });
        }
      }
    }
  }

  // 2. Detect Reordering Opportunities (Independent instructions trapped after a load-use)
  for (let i = 0; i < instructions.length - 2; i++) {
    const instr1 = instructions[i];
    const instr2 = instructions[i + 1];
    const instr3 = instructions[i + 2];

    if (loadOps.includes(instr1.mnemonic) && instr1.rd) {
      const isInstr2Dependent = instr2.rs1 === instr1.rd || instr2.rs2 === instr1.rd;
      if (isInstr2Dependent) {
        // Check if instr3 is completely independent of both instr1 and instr2
        const instr3Reads = [instr3.rs1, instr3.rs2].filter(Boolean);
        const instr3Writes = instr3.rd;
        const conflictsWith1 = instr3Reads.includes(instr1.rd) || instr3Writes === instr1.rd;
        const conflictsWith2 = instr3Reads.includes(instr2.rd) || (instr2.rd && instr3Writes === instr2.rd);

        if (!conflictsWith1 && !conflictsWith2 && !loadOps.includes(instr3.mnemonic) && !['beq', 'bne', 'jal'].includes(instr3.mnemonic)) {
          bottlenecks.push({
            id: `reorder-opt-${instr1.id}-${instr3.id}`,
            type: 'ORDERING_CONSTRAINT',
            severity: 'medium',
            title: `Instruction Scheduling Opportunity`,
            instructionsInvolved: [instr1.id, instr2.id, instr3.id],
            technicalExplanation: `Instruction ${instr3.id} ('${instr3.originalText}') is independent of Instruction ${instr1.id} and Instruction ${instr2.id}. Hoisting Instruction ${instr3.id} between ${instr1.id} and ${instr2.id} fills the load-use delay slot and eliminates 1 stall cycle.`,
            beginnerExplanation: `We have an independent chore (Instruction ${instr3.id}) that doesn't depend on the waiting groceries. We can do that chore right now while waiting, making the total run faster!`,
            impact: `Can eliminate 1 pipeline stall cycle without changing any program results.`,
            improvementSuggestion: `Move '${instr3.originalText}' above '${instr2.originalText}'.`,
            isSafeToApply: true,
          });
        }
      }
    }
  }

  // 3. Detect Redundant Operations (Dead stores, identity adds)
  for (let i = 0; i < instructions.length; i++) {
    const cur = instructions[i];

    // Identity move or addi x, x, 0
    if (cur.mnemonic === 'addi' && cur.rd === cur.rs1 && cur.imm === 0 && cur.rd !== 'x0') {
      bottlenecks.push({
        id: `redundant-identity-${cur.id}`,
        type: 'REDUNDANT_OP',
        severity: 'low',
        title: `Redundant No-Op Operation`,
        instructionsInvolved: [cur.id],
        technicalExplanation: `Instruction ${cur.id} ('${cur.originalText}') adds 0 to ${X_TO_ABI[cur.rd!] || cur.rd} and writes to itself. This wastes 1 instruction slot and 1 execution cycle.`,
        beginnerExplanation: `This line says "add zero to this number". It doesn't change anything, but the CPU still spends time processing it.`,
        impact: `Wastes 1 instruction cycle in program execution.`,
        improvementSuggestion: `Remove this instruction.`,
        isSafeToApply: true,
      });
    }

    // Dead store: register written here is immediately overwritten before being read
    if (cur.rd && cur.rd !== 'x0' && i + 1 < instructions.length) {
      const next = instructions[i + 1];
      if (next.rd === cur.rd && next.rs1 !== cur.rd && next.rs2 !== cur.rd && !loadOps.includes(next.mnemonic)) {
        bottlenecks.push({
          id: `dead-store-${cur.id}-${next.id}`,
          type: 'REDUNDANT_OP',
          severity: 'medium',
          title: `Dead Register Write on ${X_TO_ABI[cur.rd] || cur.rd}`,
          instructionsInvolved: [cur.id, next.id],
          technicalExplanation: `Instruction ${cur.id} writes to ${X_TO_ABI[cur.rd] || cur.rd}, but Instruction ${next.id} immediately overwrites the same register without any intervening read.`,
          beginnerExplanation: `Instruction ${cur.id} writes a value to a drawer, but Instruction ${next.id} immediately throws it away and puts a new value in the same drawer without anyone looking at the first value.`,
          impact: `Unnecessary instruction execution that increases total cycles.`,
          improvementSuggestion: `Eliminate Instruction ${cur.id} if its intermediate result is unused.`,
          isSafeToApply: true,
        });
      }
    }
  }

  // 4. Summary of Overall Pipeline Stalls
  if (simResult.stallCycles > 0) {
    bottlenecks.push({
      id: `total-stalls-summary`,
      type: 'PIPELINE_STALL',
      severity: simResult.stallCycles > 3 ? 'high' : 'medium',
      title: `${simResult.stallCycles} Pipeline Stall Cycle(s) Recorded`,
      instructionsInvolved: [],
      technicalExplanation: `The CPU executed ${simResult.totalCycles} cycles for ${simResult.instructionCount} instructions (CPI = ${simResult.cpi}). Out of ${simResult.totalCycles} cycles, ${simResult.stallCycles} cycle(s) were stalled bubbles with zero useful instruction graduation.`,
      beginnerExplanation: `The CPU was forced to wait for ${simResult.stallCycles} clock beats because the needed numbers weren't ready in time. This lowers the CPU's efficiency.`,
      impact: `Increases CPI from the ideal 1.000 to ${simResult.cpi}.`,
      improvementSuggestion: `Apply instruction reordering or enable forwarding to reduce idle bubble cycles.`,
      isSafeToApply: true,
    });
  }

  return bottlenecks;
}

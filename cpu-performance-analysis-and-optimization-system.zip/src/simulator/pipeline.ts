/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  CycleSnapshot,
  ForwardingEvent,
  PipelineStageState,
  RiscvInstruction,
  SimulationResult,
  StageName
} from '../types/riscv.ts';

interface InFlightInstruction {
  instr: RiscvInstruction;
  stage: StageName;
  stageCycleCount: number; // how many cycles it has spent in current stage
  aluResult?: number;
  memResult?: number;
}

export function simulatePipeline(
  instructions: RiscvInstruction[],
  forwardingEnabled: boolean = true,
  clockFrequencyMHz: number = 1000,
  programName: string = 'RISC-V Program'
): SimulationResult {
  if (instructions.length === 0) {
    return {
      programName,
      instructions: [],
      totalCycles: 0,
      instructionCount: 0,
      cpi: 0,
      ipc: 0,
      stallCycles: 0,
      forwardingEnabled,
      cycleSnapshots: [],
      spaceTimeGrid: [],
      clockPeriodNs: 1000 / clockFrequencyMHz,
      executionTimeNs: 0,
      finalRegisters: {},
    };
  }

  const clockPeriodNs = 1000 / clockFrequencyMHz;
  const cycleSnapshots: CycleSnapshot[] = [];
  
  // Register file x0-x31
  const registers: Record<string, number> = {};
  for (let i = 0; i < 32; i++) {
    registers[`x${i}`] = 0;
  }
  // Initialize some realistic base addresses
  registers['x2'] = 0x7ffffff0; // sp
  registers['x8'] = 0x10000000; // s0 base memory

  // Simulated memory array
  const memory: Record<number, number> = {
    0: 10,
    4: 25,
    8: 42,
    12: 99,
    16: 100,
    20: 250,
  };

  // Space-time grid: rows = instructions, cols = cycles
  const spaceTimeGrid: (StageName | 'STALL' | null)[][] = instructions.map(() => []);

  // Pipeline register latches
  let ifStage: RiscvInstruction | null = null;
  let idStage: RiscvInstruction | null = null;
  let exStage: { instr: RiscvInstruction; aluResult: number } | null = null;
  let memStage: { instr: RiscvInstruction; aluResult: number; memResult: number } | null = null;
  let wbStage: { instr: RiscvInstruction; writeVal: number } | null = null;

  let pcIndex = 0;
  let cycle = 1;
  let totalStalls = 0;
  const MAX_CYCLES = 500;

  while (
    (pcIndex < instructions.length || ifStage || idStage || exStage || memStage || wbStage) &&
    cycle <= MAX_CYCLES
  ) {
    const forwardingEvents: ForwardingEvent[] = [];
    let stallOccurred = false;
    let stallReason: string | undefined = undefined;

    // --- 1. WB Stage Action (Writes to register file) ---
    if (wbStage) {
      const rd = wbStage.instr.rd;
      if (rd && rd !== 'x0') {
        registers[rd] = wbStage.writeVal;
      }
    }

    // --- 2. Hazard Detection in ID Stage ---
    let stallID = false;

    if (idStage) {
      const neededRegs: string[] = [];
      if (idStage.rs1 && idStage.rs1 !== 'x0') neededRegs.push(idStage.rs1);
      if (idStage.rs2 && idStage.rs2 !== 'x0') neededRegs.push(idStage.rs2);

      for (const reg of neededRegs) {
        if (!forwardingEnabled) {
          // WITHOUT FORWARDING:
          // Must wait until producer finishes WB.
          // Check if EX produces this reg:
          if (exStage && exStage.instr.rd === reg) {
            stallID = true;
            stallReason = `RAW Hazard: '${idStage.mnemonic}' needs ${reg} written by '${exStage.instr.mnemonic}' in EX (stalling 2 cycles for WB)`;
            break;
          }
          // Check if MEM produces this reg:
          if (memStage && memStage.instr.rd === reg) {
            stallID = true;
            stallReason = `RAW Hazard: '${idStage.mnemonic}' needs ${reg} written by '${memStage.instr.mnemonic}' in MEM (stalling 1 cycle for WB)`;
            break;
          }
        } else {
          // WITH FORWARDING:
          // Check for Load-Use Hazard:
          // If instruction in EX is a LOAD and writes to a reg needed by ID,
          // load data is only ready at end of MEM stage -> MUST stall 1 cycle.
          const isExLoad = exStage && ['lw', 'lh', 'lb', 'lbu', 'lhu'].includes(exStage.instr.mnemonic);
          if (isExLoad && exStage!.instr.rd === reg) {
            stallID = true;
            stallReason = `Load-Use Hazard: '${idStage.mnemonic}' needs ${reg} loaded by '${exStage!.instr.mnemonic}' in EX (stalling 1 cycle for MEM data)`;
            break;
          }

          // Forwarding detection (informative record)
          if (exStage && exStage.instr.rd === reg && exStage.instr.rd !== 'x0') {
            forwardingEvents.push({
              cycle,
              fromStage: 'EX/MEM',
              toStage: 'EX',
              register: reg,
              fromInstrId: exStage.instr.id,
              toInstrId: idStage.id,
              description: `Forwarded ${reg} (${exStage.aluResult}) from EX/MEM to EX`,
            });
          } else if (memStage && memStage.instr.rd === reg && memStage.instr.rd !== 'x0') {
            const val = ['lw', 'lh', 'lb'].includes(memStage.instr.mnemonic) ? memStage.memResult : memStage.aluResult;
            forwardingEvents.push({
              cycle,
              fromStage: 'MEM/WB',
              toStage: 'EX',
              register: reg,
              fromInstrId: memStage.instr.id,
              toInstrId: idStage.id,
              description: `Forwarded ${reg} (${val}) from MEM/WB to EX`,
            });
          }
        }
      }
    }

    if (stallID) {
      stallOccurred = true;
      totalStalls++;
    }

    // --- Record Snapshot for this cycle ---
    const snapshot: CycleSnapshot = {
      cycle,
      stages: {
        IF: ifStage
          ? {
              instrId: ifStage.id,
              mnemonic: ifStage.originalText,
              isBubble: false,
              registersRead: [ifStage.rs1, ifStage.rs2].filter(Boolean) as string[],
              registerWritten: ifStage.rd,
            }
          : null,
        ID: idStage
          ? {
              instrId: idStage.id,
              mnemonic: idStage.originalText,
              isBubble: false,
              registersRead: [idStage.rs1, idStage.rs2].filter(Boolean) as string[],
              registerWritten: idStage.rd,
            }
          : null,
        EX: exStage
          ? {
              instrId: exStage.instr.id,
              mnemonic: exStage.instr.originalText,
              isBubble: false,
              registersRead: [exStage.instr.rs1, exStage.instr.rs2].filter(Boolean) as string[],
              registerWritten: exStage.instr.rd,
            }
          : null,
        MEM: memStage
          ? {
              instrId: memStage.instr.id,
              mnemonic: memStage.instr.originalText,
              isBubble: false,
              registersRead: [memStage.instr.rs1, memStage.instr.rs2].filter(Boolean) as string[],
              registerWritten: memStage.instr.rd,
            }
          : null,
        WB: wbStage
          ? {
              instrId: wbStage.instr.id,
              mnemonic: wbStage.instr.originalText,
              isBubble: false,
              registerWritten: wbStage.instr.rd,
            }
          : null,
      },
      pc: pcIndex * 4,
      stallOccurred,
      stallReason,
      forwardingEvents,
      registerState: { ...registers },
    };

    cycleSnapshots.push(snapshot);

    // Record into space-time grid
    if (ifStage) spaceTimeGrid[ifStage.id - 1][cycle - 1] = 'IF';
    if (idStage) {
      if (stallID) {
        spaceTimeGrid[idStage.id - 1][cycle - 1] = 'STALL';
      } else {
        spaceTimeGrid[idStage.id - 1][cycle - 1] = 'ID';
      }
    }
    if (exStage) spaceTimeGrid[exStage.instr.id - 1][cycle - 1] = 'EX';
    if (memStage) spaceTimeGrid[memStage.instr.id - 1][cycle - 1] = 'MEM';
    if (wbStage) spaceTimeGrid[wbStage.instr.id - 1][cycle - 1] = 'WB';

    // --- 3. Pipeline Advancement & Latch Updating for Next Cycle ---
    // Next WB gets current MEM
    let nextWbStage: { instr: RiscvInstruction; writeVal: number } | null = null;
    if (memStage) {
      const isLoad = ['lw', 'lh', 'lb', 'lbu', 'lhu'].includes(memStage.instr.mnemonic);
      const writeVal: number = isLoad ? memStage.memResult : memStage.aluResult;
      nextWbStage = { instr: memStage.instr, writeVal };
    }

    // Next MEM gets current EX
    let nextMemStage: { instr: RiscvInstruction; aluResult: number; memResult: number } | null = null;
    if (exStage) {
      const isLoad = ['lw', 'lh', 'lb', 'lbu', 'lhu'].includes(exStage.instr.mnemonic);
      const isStore = ['sw', 'sh', 'sb'].includes(exStage.instr.mnemonic);
      let memResult = 0;
      if (isLoad) {
        const addr = exStage.aluResult;
        memResult = memory[addr] !== undefined ? memory[addr] : (addr % 100);
      } else if (isStore) {
        const addr = exStage.aluResult;
        const storeVal = registers[exStage.instr.rs2 || 'x0'] || 0;
        memory[addr] = storeVal;
      }
      nextMemStage = {
        instr: exStage.instr,
        aluResult: exStage.aluResult,
        memResult,
      };
    }

    // Next EX gets current ID (UNLESS stalled)
    let nextExStage: { instr: RiscvInstruction; aluResult: number } | null = null;
    let nextIdStage: RiscvInstruction | null = idStage;
    let nextIfStage: RiscvInstruction | null = ifStage;

    if (stallID) {
      // BUBBLE inserted into EX stage
      nextExStage = null;
      // ID and IF hold their state
      nextIdStage = idStage;
      nextIfStage = ifStage;
    } else {
      // Normal advancement
      if (idStage) {
        // Execute operation in ALU
        const aluResult = evaluateALU(idStage, registers, memStage, nextWbStage, forwardingEnabled);
        nextExStage = { instr: idStage, aluResult };
      } else {
        nextExStage = null;
      }

      // Next ID gets current IF
      nextIdStage = ifStage;

      // Next IF fetches new instruction
      if (pcIndex < instructions.length) {
        nextIfStage = instructions[pcIndex];
        pcIndex++;
      } else {
        nextIfStage = null;
      }
    }

    // Apply latch updates
    wbStage = nextWbStage;
    memStage = nextMemStage;
    exStage = nextExStage;
    idStage = nextIdStage;
    ifStage = nextIfStage;

    cycle++;
  }

  const totalCycles = cycle - 1;
  const instructionCount = instructions.length;
  const cpi = instructionCount > 0 ? parseFloat((totalCycles / instructionCount).toFixed(3)) : 0;
  const ipc = totalCycles > 0 ? parseFloat((instructionCount / totalCycles).toFixed(3)) : 0;
  const executionTimeNs = parseFloat((totalCycles * clockPeriodNs).toFixed(2));

  return {
    programName,
    instructions,
    totalCycles,
    instructionCount,
    cpi,
    ipc,
    stallCycles: totalStalls,
    forwardingEnabled,
    cycleSnapshots,
    spaceTimeGrid,
    clockPeriodNs,
    executionTimeNs,
    finalRegisters: registers,
  };
}

function evaluateALU(
  instr: RiscvInstruction,
  registers: Record<string, number>,
  memStage: { instr: RiscvInstruction; aluResult: number; memResult: number } | null,
  wbStage: { instr: RiscvInstruction; writeVal: number } | null,
  forwardingEnabled: boolean
): number {
  // Read operand 1
  let v1 = 0;
  if (instr.rs1 && instr.rs1 !== 'x0') {
    v1 = registers[instr.rs1] || 0;
    if (forwardingEnabled) {
      if (memStage && memStage.instr.rd === instr.rs1) {
        v1 = ['lw', 'lh', 'lb'].includes(memStage.instr.mnemonic) ? memStage.memResult : memStage.aluResult;
      } else if (wbStage && wbStage.instr.rd === instr.rs1) {
        v1 = wbStage.writeVal;
      }
    }
  }

  // Read operand 2
  let v2 = 0;
  if (instr.rs2 && instr.rs2 !== 'x0') {
    v2 = registers[instr.rs2] || 0;
    if (forwardingEnabled) {
      if (memStage && memStage.instr.rd === instr.rs2) {
        v2 = ['lw', 'lh', 'lb'].includes(memStage.instr.mnemonic) ? memStage.memResult : memStage.aluResult;
      } else if (wbStage && wbStage.instr.rd === instr.rs2) {
        v2 = wbStage.writeVal;
      }
    }
  }

  const imm = instr.imm || 0;
  const op = instr.mnemonic;

  switch (op) {
    case 'add': return (v1 + v2) | 0;
    case 'addi': return (v1 + imm) | 0;
    case 'sub': return (v1 - v2) | 0;
    case 'and': return v1 & v2;
    case 'andi': return v1 & imm;
    case 'or': return v1 | v2;
    case 'ori': return v1 | imm;
    case 'xor': return v1 ^ v2;
    case 'xori': return v1 ^ imm;
    case 'sll': return v1 << (v2 & 0x1f);
    case 'slli': return v1 << (imm & 0x1f);
    case 'srl': return v1 >>> (v2 & 0x1f);
    case 'srli': return v1 >>> (imm & 0x1f);
    case 'sra': return v1 >> (v2 & 0x1f);
    case 'srai': return v1 >> (imm & 0x1f);
    case 'slt': return v1 < v2 ? 1 : 0;
    case 'slti': return v1 < imm ? 1 : 0;
    case 'mul': return Math.imul(v1, v2);
    case 'lw':
    case 'lh':
    case 'lb':
    case 'sw':
    case 'sh':
    case 'sb':
      return (v1 + imm) | 0; // effective address computation
    case 'lui': return (imm << 12) | 0;
    default: return (v1 + imm) | 0;
  }
}

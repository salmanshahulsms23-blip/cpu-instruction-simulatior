/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InstructionType, RiscvInstruction } from '../types/riscv.ts';

// Standard RISC-V Register Mapping
export const REGISTER_ALIAS_MAP: Record<string, string> = {
  // ABI names -> Canonical ABI name
  'zero': 'x0', 'x0': 'x0',
  'ra': 'x1',   'x1': 'x1',
  'sp': 'x2',   'x2': 'x2',
  'gp': 'x3',   'x3': 'x3',
  'tp': 'x4',   'x4': 'x4',
  't0': 'x5',   'x5': 'x5',
  't1': 'x6',   'x6': 'x6',
  't2': 'x7',   'x7': 'x7',
  's0': 'x8',   'fp': 'x8',  'x8': 'x8',
  's1': 'x9',   'x9': 'x9',
  'a0': 'x10',  'x10': 'x10',
  'a1': 'x11',  'x11': 'x11',
  'a2': 'x12',  'x12': 'x12',
  'a3': 'x13',  'x13': 'x13',
  'a4': 'x14',  'x14': 'x14',
  'a5': 'x15',  'x15': 'x15',
  'a6': 'x16',  'x16': 'x16',
  'a7': 'x17',  'x17': 'x17',
  's2': 'x18',  'x18': 'x18',
  's3': 'x19',  'x19': 'x19',
  's4': 'x20',  'x20': 'x20',
  's5': 'x21',  'x21': 'x21',
  's6': 'x22',  'x22': 'x22',
  's7': 'x23',  'x23': 'x23',
  's8': 'x24',  'x24': 'x24',
  's9': 'x25',  'x25': 'x25',
  's10': 'x26', 'x26': 'x26',
  's11': 'x27', 'x27': 'x27',
  't3': 'x28',  'x28': 'x28',
  't4': 'x29',  'x29': 'x29',
  't5': 'x30',  'x30': 'x30',
  't6': 'x31',  'x31': 'x31',
};

// Return canonical ABI name for display (e.g. x5 -> t0)
export const X_TO_ABI: Record<string, string> = {
  'x0': 'zero', 'x1': 'ra', 'x2': 'sp', 'x3': 'gp', 'x4': 'tp',
  'x5': 't0', 'x6': 't1', 'x7': 't2', 'x8': 's0', 'x9': 's1',
  'x10': 'a0', 'x11': 'a1', 'x12': 'a2', 'x13': 'a3', 'x14': 'a4',
  'x15': 'a5', 'x16': 'a6', 'x17': 'a7', 'x18': 's2', 'x19': 's3',
  'x20': 's4', 'x21': 's5', 'x22': 's6', 'x23': 's7', 'x24': 's8',
  'x25': 's9', 'x26': 's10', 'x27': 's11', 'x28': 't3', 'x29': 't4',
  'x30': 't5', 'x31': 't6',
};

export interface ParseResult {
  instructions: RiscvInstruction[];
  errors: string[];
  warnings: string[];
}

export function normalizeReg(reg: string): string {
  const clean = reg.trim().toLowerCase().replace(/,/g, '');
  return REGISTER_ALIAS_MAP[clean] || clean;
}

export function parseImmediate(val: string): number {
  val = val.trim();
  if (val.startsWith('0x') || val.startsWith('0X')) {
    return parseInt(val, 16);
  }
  return parseInt(val, 10);
}

export function parseAssembly(code: string): ParseResult {
  const instructions: RiscvInstruction[] = [];
  const errors: string[] = [];
  const warnings: string[] = [];

  const lines = code.split('\n');
  let currentId = 1;

  for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
    const rawLine = lines[lineIdx];
    const lineNum = lineIdx + 1;

    // Separate comment
    let textWithoutComment = rawLine;
    let comment: string | undefined = undefined;

    const commentIdx = rawLine.search(/#|\/\//);
    if (commentIdx !== -1) {
      textWithoutComment = rawLine.substring(0, commentIdx);
      comment = rawLine.substring(commentIdx).trim();
    }

    let trimmed = textWithoutComment.trim();
    if (!trimmed) continue;

    // Check for label
    let label: string | undefined = undefined;
    const labelMatch = trimmed.match(/^([a-zA-Z_][a-zA-Z0-9_]*):(.*)$/);
    if (labelMatch) {
      label = labelMatch[1];
      trimmed = labelMatch[2].trim();
      if (!trimmed) {
        // Line was just a label
        continue;
      }
    }

    // Tokenize
    // Replace commas with spaces, then split by whitespace
    const normalized = trimmed.replace(/,/g, ' ');
    const tokens = normalized.split(/\s+/).filter(t => t.length > 0);

    if (tokens.length === 0) continue;

    const mnemonic = tokens[0].toLowerCase();
    const args = tokens.slice(1);

    try {
      const parsed = parseInstruction(currentId, mnemonic, args, rawLine.trim(), lineNum, label, comment);
      instructions.push(parsed);
      currentId++;
    } catch (err: any) {
      errors.push(`Line ${lineNum}: ${err.message || 'Syntax error'}`);
    }
  }

  return { instructions, errors, warnings };
}

function parseInstruction(
  id: number,
  mnemonic: string,
  args: string[],
  originalText: string,
  line: number,
  label?: string,
  comment?: string
): RiscvInstruction {
  const rTypeOps = ['add', 'sub', 'and', 'or', 'xor', 'sll', 'srl', 'sra', 'slt', 'sltu', 'mul'];
  const iTypeArithOps = ['addi', 'andi', 'ori', 'xori', 'slli', 'srli', 'srai', 'slti', 'sltiu'];
  const loadOps = ['lw', 'lh', 'lb', 'lbu', 'lhu'];
  const storeOps = ['sw', 'sh', 'sb'];
  const branchOps = ['beq', 'bne', 'blt', 'bge', 'bltu', 'bgeu'];

  // 1. R-Type: add rd, rs1, rs2
  if (rTypeOps.includes(mnemonic)) {
    if (args.length < 3) {
      throw new Error(`${mnemonic} requires 3 operands: rd, rs1, rs2`);
    }
    const rd = validateRegister(args[0], 'rd');
    const rs1 = validateRegister(args[1], 'rs1');
    const rs2 = validateRegister(args[2], 'rs2');
    return {
      id, originalText, label, mnemonic, type: 'R', rd, rs1, rs2, line, comment
    };
  }

  // 2. I-Type Arithmetic: addi rd, rs1, imm
  if (iTypeArithOps.includes(mnemonic)) {
    if (args.length < 3) {
      throw new Error(`${mnemonic} requires 3 operands: rd, rs1, imm`);
    }
    const rd = validateRegister(args[0], 'rd');
    const rs1 = validateRegister(args[1], 'rs1');
    const imm = parseImmediate(args[2]);
    if (isNaN(imm)) throw new Error(`Invalid immediate value '${args[2]}'`);
    return {
      id, originalText, label, mnemonic, type: 'I', rd, rs1, imm, line, comment
    };
  }

  // 3. Load Ops: lw rd, offset(rs1) OR lw rd, rs1, offset
  if (loadOps.includes(mnemonic)) {
    if (args.length === 2) {
      const rd = validateRegister(args[0], 'rd');
      const offsetMatch = args[1].match(/^(-?\d+|0x[0-9a-fA-F]+)\(([a-zA-Z0-9]+)\)$/);
      if (offsetMatch) {
        const imm = parseImmediate(offsetMatch[1]);
        const rs1 = validateRegister(offsetMatch[2], 'rs1');
        return { id, originalText, label, mnemonic, type: 'I', rd, rs1, imm, line, comment };
      } else {
        // Maybe format: lw rd, rs1
        const rs1 = validateRegister(args[1], 'rs1');
        return { id, originalText, label, mnemonic, type: 'I', rd, rs1, imm: 0, line, comment };
      }
    } else if (args.length >= 3) {
      const rd = validateRegister(args[0], 'rd');
      const rs1 = validateRegister(args[1], 'rs1');
      const imm = parseImmediate(args[2]);
      return { id, originalText, label, mnemonic, type: 'I', rd, rs1, imm: isNaN(imm) ? 0 : imm, line, comment };
    }
    throw new Error(`${mnemonic} requires destination register and address e.g. '${mnemonic} t0, 0(s0)'`);
  }

  // 4. Store Ops: sw rs2, offset(rs1)
  if (storeOps.includes(mnemonic)) {
    if (args.length === 2) {
      const rs2 = validateRegister(args[0], 'rs2');
      const offsetMatch = args[1].match(/^(-?\d+|0x[0-9a-fA-F]+)\(([a-zA-Z0-9]+)\)$/);
      if (offsetMatch) {
        const imm = parseImmediate(offsetMatch[1]);
        const rs1 = validateRegister(offsetMatch[2], 'rs1');
        return { id, originalText, label, mnemonic, type: 'S', rs1, rs2, imm, line, comment };
      } else {
        const rs1 = validateRegister(args[1], 'rs1');
        return { id, originalText, label, mnemonic, type: 'S', rs1, rs2, imm: 0, line, comment };
      }
    } else if (args.length >= 3) {
      const rs2 = validateRegister(args[0], 'rs2');
      const rs1 = validateRegister(args[1], 'rs1');
      const imm = parseImmediate(args[2]);
      return { id, originalText, label, mnemonic, type: 'S', rs1, rs2, imm: isNaN(imm) ? 0 : imm, line, comment };
    }
    throw new Error(`${mnemonic} requires source register and address e.g. '${mnemonic} t0, 0(s0)'`);
  }

  // 5. Branch Ops: beq rs1, rs2, label/offset
  if (branchOps.includes(mnemonic)) {
    if (args.length < 3) {
      throw new Error(`${mnemonic} requires rs1, rs2, and target`);
    }
    const rs1 = validateRegister(args[0], 'rs1');
    const rs2 = validateRegister(args[1], 'rs2');
    const imm = parseImmediate(args[2]);
    return {
      id, originalText, label, mnemonic, type: 'B', rs1, rs2, imm: isNaN(imm) ? 0 : imm, line, comment
    };
  }

  // 6. Pseudo-instruction: li rd, imm (load immediate)
  if (mnemonic === 'li') {
    if (args.length < 2) throw new Error('li requires rd, imm');
    const rd = validateRegister(args[0], 'rd');
    const imm = parseImmediate(args[1]);
    return {
      id, originalText, label, mnemonic: 'addi', type: 'I', rd, rs1: 'x0', imm: isNaN(imm) ? 0 : imm, line, comment
    };
  }

  // 7. Pseudo-instruction: mv rd, rs1 (move)
  if (mnemonic === 'mv') {
    if (args.length < 2) throw new Error('mv requires rd, rs1');
    const rd = validateRegister(args[0], 'rd');
    const rs1 = validateRegister(args[1], 'rs1');
    return {
      id, originalText, label, mnemonic: 'addi', type: 'I', rd, rs1, imm: 0, line, comment
    };
  }

  // 8. Pseudo-instruction: nop
  if (mnemonic === 'nop') {
    return {
      id, originalText, label, mnemonic: 'addi', type: 'I', rd: 'x0', rs1: 'x0', imm: 0, line, comment
    };
  }

  // 9. lui rd, imm
  if (mnemonic === 'lui') {
    if (args.length < 2) throw new Error('lui requires rd, imm');
    const rd = validateRegister(args[0], 'rd');
    const imm = parseImmediate(args[1]);
    return {
      id, originalText, label, mnemonic, type: 'U', rd, imm: isNaN(imm) ? 0 : imm, line, comment
    };
  }

  // 10. jal rd, offset / j label
  if (mnemonic === 'jal') {
    if (args.length === 1) {
      // jal label -> jal ra, label
      const imm = parseImmediate(args[0]);
      return { id, originalText, label, mnemonic: 'jal', type: 'J', rd: 'x1', imm: isNaN(imm) ? 0 : imm, line, comment };
    }
    const rd = validateRegister(args[0], 'rd');
    const imm = parseImmediate(args[1]);
    return { id, originalText, label, mnemonic: 'jal', type: 'J', rd, imm: isNaN(imm) ? 0 : imm, line, comment };
  }

  if (mnemonic === 'j') {
    const imm = args[0] ? parseImmediate(args[0]) : 0;
    return { id, originalText, label, mnemonic: 'jal', type: 'J', rd: 'x0', imm: isNaN(imm) ? 0 : imm, line, comment };
  }

  // Fallback for unknown mnemonic
  throw new Error(`Unsupported or unknown RISC-V instruction: '${mnemonic}'`);
}

function validateRegister(token: string, role: string): string {
  const norm = normalizeReg(token);
  if (!norm || !norm.startsWith('x') || isNaN(parseInt(norm.substring(1), 10))) {
    throw new Error(`Invalid register for ${role}: '${token}'`);
  }
  const regNum = parseInt(norm.substring(1), 10);
  if (regNum < 0 || regNum > 31) {
    throw new Error(`Register out of range (x0-x31): '${token}'`);
  }
  return norm;
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type StageName = 'IF' | 'ID' | 'EX' | 'MEM' | 'WB';

export type InstructionType = 'R' | 'I' | 'S' | 'B' | 'U' | 'J' | 'PSEUDO';

export interface RiscvInstruction {
  id: number;
  originalText: string;
  label?: string;
  mnemonic: string;
  type: InstructionType;
  rd?: string;
  rs1?: string;
  rs2?: string;
  imm?: number;
  line: number;
  comment?: string;
}

export interface PipelineStageState {
  instrId: number | null; // null if bubble/stall
  mnemonic: string;
  isBubble: boolean;
  bubbleReason?: string;
  registersRead?: string[];
  registerWritten?: string;
}

export interface ForwardingEvent {
  cycle: number;
  fromStage: 'EX/MEM' | 'MEM/WB';
  toStage: 'EX';
  register: string;
  fromInstrId: number;
  toInstrId: number;
  description: string;
}

export interface CycleSnapshot {
  cycle: number;
  stages: {
    IF: PipelineStageState | null;
    ID: PipelineStageState | null;
    EX: PipelineStageState | null;
    MEM: PipelineStageState | null;
    WB: PipelineStageState | null;
  };
  pc: number;
  stallOccurred: boolean;
  stallReason?: string;
  forwardingEvents: ForwardingEvent[];
  registerState: Record<string, number>;
}

export interface SimulationResult {
  programName: string;
  instructions: RiscvInstruction[];
  totalCycles: number;
  instructionCount: number;
  cpi: number;
  ipc: number;
  stallCycles: number;
  forwardingEnabled: boolean;
  cycleSnapshots: CycleSnapshot[];
  // Space-time matrix: for each instruction (row), stage at cycle c (column index c - 1)
  // Values: 'IF' | 'ID' | 'EX' | 'MEM' | 'WB' | 'STALL' | null
  spaceTimeGrid: (StageName | 'STALL' | null)[][];
  clockPeriodNs: number; // in nanoseconds
  executionTimeNs: number;
  finalRegisters: Record<string, number>;
}

export interface BottleneckItem {
  id: string;
  type: 'RAW_HAZARD' | 'LOAD_USE_HAZARD' | 'PIPELINE_STALL' | 'ORDERING_CONSTRAINT' | 'REDUNDANT_OP' | 'LOOP_OVERHEAD';
  severity: 'high' | 'medium' | 'low' | 'info';
  title: string;
  instructionsInvolved: number[]; // instruction IDs
  technicalExplanation: string;
  beginnerExplanation: string;
  impact: string;
  improvementSuggestion: string;
  isSafeToApply: boolean;
}

export interface OptimizationRecommendation {
  id: string;
  title: string;
  category: 'REORDERING' | 'REDUNDANCY_REMOVAL' | 'STALL_REDUCTION' | 'DEAD_CODE';
  description: string;
  rationale: string;
  confidence: 'guaranteed_safe' | 'heuristic';
  suggestedAssembly: string;
  estimatedStallReduction: number;
}

export interface ComparisonMetrics {
  originalResult: SimulationResult;
  optimizedResult: SimulationResult;
  originalCycles: number;
  optimizedCycles: number;
  cycleReductionPct: number;
  originalCPI: number;
  optimizedCPI: number;
  originalStallCycles: number;
  optimizedStallCycles: number;
  isImprovement: boolean;
  verdictExplanation: string;
}

export interface SampleProgram {
  id: string;
  name: string;
  description: string;
  assembly: string;
  concepts: string[];
  expectedOutput: string;
  defaultForwarding: boolean;
}

export interface VerificationTest {
  id: string;
  name: string;
  category: 'PARSER' | 'DEPENDENCY' | 'PIPELINE' | 'METRICS' | 'OPTIMIZATION';
  description: string;
  run: () => { pass: boolean; details: string; expected: any; actual: any };
}

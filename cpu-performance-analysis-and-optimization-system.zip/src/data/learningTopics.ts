/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LearningTopic {
  id: string;
  title: string;
  subtitle: string;
  analogy: string;
  technicalDefinition: string;
  keyPoints: string[];
  formula?: string;
  example: string;
  diagramAscii?: string;
}

export const LEARNING_TOPICS: LearningTopic[] = [
  {
    id: 'what-is-cpu',
    title: '1. What is a CPU?',
    subtitle: 'The Brain and Engine of the Computer',
    analogy: 'Think of the Central Processing Unit (CPU) as the master chef in a restaurant kitchen. The chef reads recipes (instructions) step-by-step, grabs ingredients from cutting boards (registers) or the pantry (RAM), cuts and mixes them (ALU), and plates the finished dish.',
    technicalDefinition: 'The CPU (Central Processing Unit) is the electronic circuitry within a computer that executes instructions comprising a computer program. It performs basic arithmetic, logic, controlling, and input/output (I/O) operations specified by the instructions in the program.',
    keyPoints: [
      'Control Unit (CU): Directs the flow of data and instructions through the processor.',
      'Arithmetic Logic Unit (ALU): Executes mathematical operations (addition, subtraction, multiplication) and logical comparisons (AND, OR, XOR).',
      'Register File: Ultra-fast internal temporary storage cells directly accessible within 1 clock cycle.',
      'Program Counter (PC): Special register that holds the memory address of the next instruction to fetch.',
    ],
    example: 'When you run `add t0, t1, t2`, the CPU retrieves the numbers stored in t1 and t2, adds them inside the ALU, and writes the sum into t0.',
    diagramAscii: `
+-----------------------------------------------------------+
|                          C P U                            |
|  +--------------------+        +-----------------------+  |
|  |    Control Unit    | <----> | Arithmetic Logic Unit |  |
|  |  (Decodes & Rules) |        |       (ALU Math)      |  |
|  +--------------------+        +-----------------------+  |
|            ^                               ^              |
|            v                               v              |
|  +-----------------------------------------------------+  |
|  |            Register File (x0 to x31)               |  |
|  +-----------------------------------------------------+  |
+-----------------------------------------------------------+
            ^                               ^
            |  Data Bus                     |  Address Bus
            v                               v
+-----------------------------------------------------------+
|               System Memory (RAM / Caches)                |
+-----------------------------------------------------------+`,
  },
  {
    id: 'what-are-registers',
    title: '2. What are Registers?',
    subtitle: 'Scratchpad Memory on the Chip Silicon',
    analogy: 'Imagine having 32 sticky notes taped right in front of your eyes on your desk. You can read and write on them instantly without standing up or opening any filing cabinet drawers.',
    technicalDefinition: 'Registers are high-speed, small-capacity storage locations directly built into the CPU silicon die. In the 32-bit RISC-V ISA (RV32I), there are 32 general-purpose registers named x0 through x31, each 32 bits wide.',
    keyPoints: [
      'x0 (zero): Hardwired to constant zero. Any write to x0 is ignored; reading x0 always yields 0.',
      'x1 (ra): Return address for function calls.',
      'x2 (sp): Stack pointer pointing to active stack frame.',
      'x5-x7, x28-x31 (t0-t6): Temporary registers that functions can overwrite without saving.',
      'x8-x9, x18-x27 (s0-s11): Saved registers that functions must preserve across calls.',
      'x10-x17 (a0-a7): Function arguments and return values.',
    ],
    example: 'In RISC-V, you cannot add memory directly to memory: `add 0(s0), 4(s0)` is invalid! You must first load values into registers (`lw t0, 0(s0)`), compute in registers (`add t2, t0, t1`), and store back (`sw t2, 8(s0)`). This is called a Load-Store Architecture.',
  },
  {
    id: 'what-are-instructions',
    title: '3. What are Instructions?',
    subtitle: 'The Atomic Words of Machine Language',
    analogy: 'Instructions are like individual sentences in a musical score or LEGO building manual: each tells the performer to perform exactly one small, unambiguous move.',
    technicalDefinition: 'An instruction is a single operation of a processor defined by the processor instruction set architecture (ISA). In RISC-V 32I, every base instruction is exactly 32 bits (4 bytes) long with fixed, regular field layouts.',
    keyPoints: [
      'R-Type (Register): 2 source registers, 1 destination register. (e.g. `add rd, rs1, rs2`)',
      'I-Type (Immediate): 1 source register, 1 constant immediate, 1 destination. (e.g. `addi rd, rs1, imm` or `lw rd, imm(rs1)`)',
      'S-Type (Store): 2 source registers and an offset immediate. (e.g. `sw rs2, offset(rs1)`)',
      'B-Type (Branch): Compares 2 registers and jumps relative to PC if true. (e.g. `beq rs1, rs2, label`)',
      'U-Type (Upper Imm): Loads 20-bit immediate into top 20 bits. (e.g. `lui rd, imm`)',
      'J-Type (Jump): Unconditional jump and link return address. (e.g. `jal rd, offset`)',
    ],
    example: 'Instruction: `addi t0, zero, 42`. Opcode specifies addition with immediate, rd specifies register x5 (t0), rs1 specifies x0 (zero), and immediate field encodes 42.',
  },
  {
    id: 'instruction-cycle',
    title: '4. What is an Instruction Cycle?',
    subtitle: 'The Universal Heartbeat: Fetch, Decode, Execute',
    analogy: 'Like breathing in air, using oxygen, and breathing out carbon dioxide, the CPU repeats a relentless three-part loop millions or billions of times every second.',
    technicalDefinition: 'The instruction cycle (or fetch-decode-execute cycle) is the fundamental operational process through which a CPU executes each machine language instruction in a computer program.',
    keyPoints: [
      '1. Fetch: The Program Counter (PC) specifies the instruction memory address. The 32-bit instruction is fetched into the Instruction Register, and PC increments by 4.',
      '2. Decode: The Control Unit analyzes the opcode, function bits, and reads operand values from the register file.',
      '3. Execute: The ALU performs the computation, evaluates effective memory addresses, or tests branch conditions.',
      '4. Memory Access: If the instruction is a Load or Store, the CPU reads from or writes to the data cache/RAM.',
      '5. Write Back: The final computed or loaded result is written into the destination register.',
    ],
    example: 'In a non-pipelined single-cycle CPU, all 5 steps happen in 1 huge clock cycle. The clock frequency must be slowed down to accommodate the slowest possible instruction (usually `lw`).',
  },
  {
    id: 'what-is-pipelining',
    title: '5. What is Pipelining?',
    subtitle: 'The Automobile Assembly Line of Computer Chips',
    analogy: 'Imagine an automated car wash or laundry line: Instead of waiting for one load to wash, dry, fold, and iron before putting the next load into the washer, you put a new load into the washer the moment the previous load advances to the dryer! All 4 machines run simultaneously.',
    technicalDefinition: 'Pipelining is an implementation technique where multiple instructions are overlapped in execution. The classic RISC pipeline consists of 5 stages: Instruction Fetch (IF), Instruction Decode (ID), Execute (EX), Memory Access (MEM), and Write Back (WB).',
    keyPoints: [
      'Increases instruction throughput (instructions completed per second) by approximately 5x.',
      'Does not decrease individual instruction latency (each instruction still takes 5 cycles from start to finish).',
      'Ideal Throughput: After the 4-cycle warmup delay, 1 instruction finishes every single clock cycle!',
      'Pipeline Registers (latches): Storage buffers (IF/ID, ID/EX, EX/MEM, MEM/WB) isolate each stage at every clock tick.',
    ],
    formula: 'Speedup_{ideal} = \\frac{\\text{Stages} \\times N}{\\text{Stages} + N - 1} \\approx \\text{Number of Stages (5)}',
    example: 'In Cycle 5 of an ideal pipeline: Instruction 1 is in WB, Instruction 2 is in MEM, Instruction 3 is in EX, Instruction 4 is in ID, and Instruction 5 is in IF. All five stages are actively working simultaneously.',
    diagramAscii: `
Cycle:      1    2    3    4    5    6    7    8
Instr 1:  [IF] [ID] [EX] [MEM][WB]
Instr 2:       [IF] [ID] [EX] [MEM][WB]
Instr 3:            [IF] [ID] [EX] [MEM][WB]
Instr 4:                 [IF] [ID] [EX] [MEM][WB]
Instr 5:                      [IF] [ID] [EX] [MEM][WB]`,
  },
  {
    id: 'what-is-cpi',
    title: '6. What is CPI & IPC?',
    subtitle: 'The Standard Currency of Processor Performance',
    analogy: 'Think of CPI (Cycles Per Instruction) like the gas mileage (gallons per mile) of a car: lower is better! IPC (Instructions Per Cycle) is like speed (miles per hour): higher is better.',
    technicalDefinition: 'Cycles Per Instruction (CPI) measures the average number of clock cycles required to execute a single machine instruction. Instructions Per Cycle (IPC) is its mathematical inverse.',
    keyPoints: [
      'Ideal 5-stage in-order pipeline CPI = 1.0 (after fill cycles).',
      'Real-world pipelines have CPI > 1.0 due to pipeline stalls (data hazards, control hazards, cache misses).',
      'Execution Time depends on the classic Iron Law of Processor Performance: Time = Instructions x CPI x Clock Period.',
    ],
    formula: 'CPI = \\frac{\\text{Total Clock Cycles}}{\\text{Total Instructions}} \\quad \\Longleftrightarrow \\quad IPC = \\frac{1}{CPI} = \\frac{\\text{Total Instructions}}{\\text{Total Clock Cycles}}',
    example: 'If a program executes 10 instructions in 14 clock cycles, CPI = 14 / 10 = 1.400 cycles/instruction, and IPC = 10 / 14 = 0.714 instructions/cycle.',
  },
  {
    id: 'pipeline-hazards',
    title: '7. What are Pipeline Hazards?',
    subtitle: 'Obstacles That Prevent Next Instruction Execution',
    analogy: 'A hazard is like a bottleneck on a highway: a traffic light (Control hazard), waiting for a part delivery (Data hazard), or two trucks trying to use the same narrow bridge simultaneously (Structural hazard).',
    technicalDefinition: 'Hazards are situations in pipelining that prevent the next instruction in the instruction stream from executing in its designated clock cycle. Hazards are categorized into Structural, Data, and Control hazards.',
    keyPoints: [
      'Structural Hazard: Hardware resource conflict (e.g. if the CPU only had 1 memory port for both instruction fetch and data read). Harvard architecture avoids this.',
      'Data Hazard: Instruction depends on the data result of a previous instruction still in the pipeline.',
      'Control Hazard: The pipeline makes a decision based on the output of a branch instruction while other instructions are already fetched.',
    ],
    example: 'If instruction i writes to t0, and instruction i+1 reads t0, instruction i+1 cannot proceed without the updated value. This is a Read-After-Write (RAW) hazard.',
  },
  {
    id: 'data-dependencies',
    title: '8. What are Data Dependencies (RAW, WAR, WAW)?',
    subtitle: 'Ordering Relationships Between Variables',
    analogy: 'RAW is like baking: you cannot ice a cake (consumer) before the cake comes out of the oven (producer). Trying to ice air results in a mess!',
    technicalDefinition: 'Data hazards arise from pipeline overlaps where the order of reads and writes to registers deviates from strict sequential execution.',
    keyPoints: [
      'RAW (Read-After-Write): "True Dependency". The consumer tries to read a register before the producer writes it. Most common and crucial hazard in pipelined CPUs.',
      'WAR (Write-After-Read): "Anti-dependency". Consumer tries to write before an older instruction reads. (Only occurs in out-of-order execution, impossible in standard 5-stage in-order).',
      'WAW (Write-After-Write): "Output dependency". Newer instruction tries to write before an older instruction writes. (Only occurs in out-of-order or variable-latency pipelines).',
    ],
    example: `addi t0, zero, 10
add  t1, t0, t2   <-- RAW True Dependency on register t0`,
  },
  {
    id: 'pipeline-stalls-forwarding',
    title: '9. Pipeline Stalls & Data Forwarding',
    subtitle: 'Hardware Bubbles vs Silicon Shortcut Bypasses',
    analogy: 'A stall is like halting the factory belt: workers stand idle. Forwarding is like handing a hot metal bolt directly across to the next worker on the bench with tongs, rather than putting it in a warehouse box and waiting for the warehouse truck to deliver it.',
    technicalDefinition: 'A stall (or bubble) is a cycle where no useful work is performed; the IF and ID stages freeze, and a NOP bubble is inserted into EX. Data Forwarding (bypassing) routes computed results directly from pipeline register latches (EX/MEM or MEM/WB) back to ALU inputs without waiting for register file writeback.',
    keyPoints: [
      'Without Forwarding: ALU-to-ALU RAW dependency requires 2 stall cycles!',
      'With Forwarding: EX/MEM-to-EX forwarding reduces ALU-to-ALU stall cycles to ZERO.',
      'Load-Use Hazard Exception: Because data from memory is only retrieved in the MEM stage, a load followed immediately by an ALU consumer ALWAYS requires 1 stall cycle, even with forwarding.',
    ],
    formula: '\\text{Stall Cycles}_{\\text{no forwarding}} = 2, \\quad \\text{Stall Cycles}_{\\text{forwarding (ALU)}} = 0, \\quad \\text{Stall Cycles}_{\\text{forwarding (Load-Use)}} = 1',
    example: 'In `lw t0, 0(s0)` followed by `add t1, t0, t2`: with forwarding, the CPU stalls 1 cycle so `lw` reaches MEM, then forwards memory data to EX.',
  },
  {
    id: 'instruction-optimization',
    title: '10. Instruction-Level Optimization & Scheduling',
    subtitle: 'Rearranging Work to Eliminate Idle Bubbles',
    analogy: 'If you are cooking pasta and have to wait 1 minute for water to boil, do not stand still staring at the pot! Chop the garlic and basil during that 1-minute boiling delay slot. Your dinner finishes 1 minute sooner.',
    technicalDefinition: 'Instruction Scheduling is a compiler optimization technique that reorders machine instructions to fill hazard delay slots (such as the load-use delay) with independent, productive instructions while strictly preserving register dependencies and program semantics.',
    keyPoints: [
      'Instruction Reordering: Find an independent instruction later in the basic block and move it between the load and its dependent consumer.',
      'Dead Code Elimination: Remove instructions whose results are never read or are immediately overwritten.',
      'Constant Folding: Precompute arithmetic expressions involving immediate constants at compile/assembly time.',
      'Loop Unrolling: Duplicate the body of a loop to reduce branch evaluation overhead and expose larger instruction scheduling windows.',
    ],
    example: `Unoptimized:
  lw   t0, 0(s0)
  add  t1, t0, s1     <-- 1 STALL BUBBLE
  addi t2, zero, 100  <-- Independent instruction!

Optimized (Scheduled):
  lw   t0, 0(s0)
  addi t2, zero, 100  <-- Executed during memory wait!
  add  t1, t0, s1     <-- 0 STALLS! Total cycles reduced by 1.`,
  },
];

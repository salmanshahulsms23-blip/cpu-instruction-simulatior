/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SampleProgram } from '../types/riscv.ts';

export const SAMPLE_PROGRAMS: SampleProgram[] = [
  {
    id: 'arithmetic',
    name: '1. Basic Arithmetic Operations',
    description: 'Demonstrates simple register initialization, addition, subtraction, logical AND, and multiplication without memory access.',
    assembly: `# Basic Arithmetic Operations
# Initialize registers
addi t0, zero, 15    # t0 = 15
addi t1, zero, 25    # t1 = 25
add  t2, t0, t1      # t2 = 15 + 25 = 40
sub  t3, t1, t0      # t3 = 25 - 15 = 10
and  t4, t0, t1      # t4 = 15 & 25 = 9
mul  t5, t0, t1      # t5 = 15 * 25 = 375`,
    concepts: [
      'Register Immediate (addi)',
      'ALU Operations (add, sub, and, mul)',
      'Pipelined execution without memory hazards',
      'Forwarding effectiveness for back-to-back ALU instructions',
    ],
    expectedOutput: 't0=15, t1=25, t2=40, t3=10, t4=9, t5=375',
    defaultForwarding: true,
  },
  {
    id: 'data-dependency',
    name: '2. Data Dependency Demonstration (RAW Chain)',
    description: 'A tight cascade of Read-After-Write (RAW) true dependencies where every subsequent instruction requires the result of the previous instruction.',
    assembly: `# Data Dependency Demonstration (RAW Chain)
# Each instruction depends directly on the result of the preceding one
addi t0, zero, 5     # t0 = 5
add  t1, t0, t0      # t1 = t0 + t0 = 10 (RAW on t0)
add  t2, t1, t0      # t2 = t1 + t0 = 15 (RAW on t1 and t0)
add  t3, t2, t1      # t3 = t2 + t1 = 25 (RAW on t2 and t1)
add  t4, t3, t2      # t4 = t3 + t2 = 40 (RAW on t3 and t2)`,
    concepts: [
      'Read-After-Write (RAW) true data dependency',
      'Severe stalls in pipeline WITHOUT forwarding (2 stalls per dependent ALU pair)',
      'Hardware EX/MEM-to-EX bypassing resolving back-to-back dependencies with 0 stalls',
    ],
    expectedOutput: 't0=5, t1=10, t2=15, t3=25, t4=40. Watch stall cycles explode when forwarding is disabled!',
    defaultForwarding: true,
  },
  {
    id: 'independent',
    name: '3. Independent Instruction Sequence',
    description: 'Instructions with zero inter-register dependencies executing in pure parallel pipeline overlap, achieving theoretical maximum CPI of 1.0 (excluding fill/drain).',
    assembly: `# Independent Instruction Sequence
# Zero data hazards across registers
addi t0, zero, 10    # t0 = 10
addi t1, zero, 20    # t1 = 20
addi t2, zero, 30    # t2 = 30
addi t3, zero, 40    # t3 = 40
addi t4, zero, 50    # t4 = 50
addi t5, zero, 60    # t5 = 60`,
    concepts: [
      'Instruction-Level Parallelism (ILP)',
      'Ideal pipeline flow (1 instruction completed per cycle after warmup)',
      'Zero stall bubbles regardless of forwarding mode',
      'Asymptotic CPI approaching 1.000',
    ],
    expectedOutput: 't0=10, t1=20, t2=30, t3=40, t4=50, t5=60 with 0 stalls.',
    defaultForwarding: true,
  },
  {
    id: 'reordering',
    name: '4. Instruction Reordering Example (Load-Use Trap)',
    description: 'A classic compiler optimization scenario: a load instruction immediately followed by its consumer causes a 1-cycle stall bubble. Reordering independent instructions eliminates the bubble!',
    assembly: `# Instruction Reordering Example
# Demonstrates Load-Use hazard and scheduling fix
lw   t0, 0(s0)       # Load value from memory address [s0] into t0
add  t1, t0, s1      # Load-Use hazard! t1 needs t0, forcing 1-cycle stall bubble
addi t2, zero, 100   # Independent instruction that could be scheduled earlier!
addi t3, zero, 200   # Another independent instruction
add  t4, t2, t3      # Computes 100 + 200 = 300`,
    concepts: [
      'Load-Use Data Hazard (data not ready until MEM stage)',
      'Incurred 1 stall bubble even with full forwarding',
      'Compiler instruction scheduling (hoisting independent addi into delay slot)',
      'Semantic preservation while eliminating idle bubbles',
    ],
    expectedOutput: 'Original has 1 stall bubble. Optimization hoists addi t2, zero, 100 into the delay slot, reducing total cycles by 1.',
    defaultForwarding: true,
  },
  {
    id: 'loop',
    name: '5. Loop Execution & Branch Demonstration',
    description: 'Simulates loop counter decrement and conditional accumulation, illustrating branch evaluation and control pipeline behavior.',
    assembly: `# Loop Execution Example
# Accumulates sum in t1 for a fixed count in t0
addi t0, zero, 3     # Loop counter = 3
addi t1, zero, 0     # Sum accumulator = 0
addi t2, zero, 5     # Value to add = 5
add  t1, t1, t2      # Iteration 1: sum += 5 (t1 = 5)
addi t0, t0, -1      # Decrement counter: t0 = 2
add  t1, t1, t2      # Iteration 2: sum += 5 (t1 = 10)
addi t0, t0, -1      # Decrement counter: t0 = 1
add  t1, t1, t2      # Iteration 3: sum += 5 (t1 = 15)
addi t0, t0, -1      # Loop ends: t0 = 0`,
    concepts: [
      'Sequential loop unrolling model',
      'Accumulator dependencies',
      'Branch and loop execution overhead',
      'Instruction count vs cycle trade-offs',
    ],
    expectedOutput: 'Final sum in t1 = 15, counter t0 = 0.',
    defaultForwarding: true,
  },
  {
    id: 'memory',
    name: '6. Memory Access Example (Load & Store Sequence)',
    description: 'Demonstrates reading multiple data elements from memory, performing calculations, and writing the result back to memory using lw and sw.',
    assembly: `# Memory Access Example
# Load elements, perform computation, and store back
lw   t0, 0(s0)       # Read element A from memory[s0 + 0]
lw   t1, 4(s0)       # Read element B from memory[s0 + 4]
add  t2, t0, t1      # Compute sum = A + B
sw   t2, 8(s0)       # Store result into memory[s0 + 8]
lw   t3, 8(s0)       # Verify by loading stored result back into t3`,
    concepts: [
      'Memory stage interactions in 5-stage pipeline',
      'Structural Harvard architecture (simultaneous IF and MEM)',
      'Store-load dependencies in memory',
      'Memory access latency and forwarding',
    ],
    expectedOutput: 'Loads values, computes sum in t2, writes to memory offset 8, and reloads verified value into t3.',
    defaultForwarding: true,
  },
  {
    id: 'dsp-kernel',
    name: '7. DSP Dot-Product Kernel (Advanced)',
    description: 'Realistic micro-kernel computing a 2-element dot product: (A0*B0) + (A1*B1), illustrating multiplier and memory pipelining.',
    assembly: `# DSP Dot-Product Micro-Kernel
lw   a0, 0(s0)       # Load vector A[0]
lw   a1, 4(s0)       # Load vector A[1]
lw   a2, 8(s0)       # Load vector B[0]
lw   a3, 12(s0)      # Load vector B[1]
mul  t0, a0, a2      # Product 1: A[0] * B[0]
mul  t1, a1, a3      # Product 2: A[1] * B[1]
add  s2, t0, t1      # Dot product accumulator: s2 = t0 + t1
sw   s2, 16(s0)      # Save dot product result to memory`,
    concepts: [
      'Multi-operand dependency graph',
      'Memory pipelining with interleaving loads',
      'Arithmetic and multiplication fusion',
      'Maximizing pipeline throughput in scientific computing',
    ],
    expectedOutput: 'Computes dot product of two 2D vectors and stores result to memory[s0 + 16].',
    defaultForwarding: true,
  },
];

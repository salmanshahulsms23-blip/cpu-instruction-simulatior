/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';

interface AdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  codeContext: string;
}

export const AdvisorModal: React.FC<AdvisorModalProps> = ({
  isOpen,
  onClose,
  codeContext,
}) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAsk = async (textToAsk: string) => {
    if (!textToAsk.trim()) return;
    setLoading(true);
    setAnswer(null);

    try {
      const res = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToAsk,
          codeContext,
        }),
      });
      const data = await res.json();
      setAnswer(data.response || data.error || 'No response generated.');
    } catch (err: any) {
      setAnswer(`Error contacting advisor: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    'Why does a load instruction cause a stall bubble even when forwarding is enabled?',
    'How does Tomasulo algorithm / Out-of-Order execution differ from this 5-stage in-order pipeline?',
    'Review my current assembly program and explain all data dependencies and scheduling strategies.',
    'Explain the structural difference between Harvard and Von Neumann architectures in pipelining.',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-3xl p-6 shadow-2xl space-y-4 max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-indigo-600 flex items-center justify-center text-sm font-bold text-white shadow-md">
              ⚡
            </span>
            <div>
              <h3 className="text-base font-bold text-white">
                Deep Architecture Advisor (High Thinking)
              </h3>
              <p className="text-[11px] text-cyan-400 font-mono">
                Model: gemini-4-argon • ThinkingLevel.HIGH
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-sm font-bold transition"
          >
            ✕
          </button>
        </div>

        {/* Quick Sample Prompts */}
        <div className="space-y-1.5">
          <span className="text-[11px] text-slate-400 font-medium">Suggested Architecture Questions:</span>
          <div className="flex flex-wrap gap-1.5">
            {samplePrompts.map((p, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setQuery(p);
                  handleAsk(p);
                }}
                className="text-left px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[11px] transition"
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Input Field */}
        <div className="flex gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAsk(query)}
            placeholder="Ask anything about RISC-V pipelining, hazards, CPI, or ILP..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
          />
          <button
            onClick={() => handleAsk(query)}
            disabled={loading || !query.trim()}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-40 text-white font-bold text-xs shadow-lg shadow-cyan-900/40 transition flex items-center gap-1.5"
          >
            {loading ? 'Thinking...' : 'Ask Advisor'}
          </button>
        </div>

        {/* Output Section */}
        <div className="flex-1 overflow-y-auto min-h-[160px] bg-slate-950 rounded-2xl p-4 border border-slate-800/80 text-xs text-slate-200 leading-relaxed font-sans">
          {loading && (
            <div className="flex items-center justify-center h-full gap-3 text-cyan-400">
              <span className="animate-spin text-lg">⚙</span>
              <span className="font-mono text-xs">Analyzing microarchitecture with high-reasoning thinking mode...</span>
            </div>
          )}

          {!loading && !answer && (
            <div className="text-slate-500 text-center py-8">
              Click any question above or type your query to receive in-depth architectural reasoning from Gemini 4 Argon with High Thinking.
            </div>
          )}

          {!loading && answer && (
            <div className="space-y-3 whitespace-pre-wrap font-sans text-xs">
              <div className="flex items-center gap-2 text-cyan-400 font-bold border-b border-slate-800 pb-2">
                <span>🎓 Architecture Analysis:</span>
              </div>
              <div className="text-slate-200 leading-relaxed">{answer}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { OptimizationAnalysis } from '../simulator/optimizer.ts';
import { StageName } from '../types/riscv.ts';

interface OptimizationViewProps {
  optimizationAnalysis: OptimizationAnalysis;
  onApplyOptimizedCode: (newAssembly: string) => void;
}

const STAGE_COLORS: Record<StageName | 'STALL', { bg: string; text: string; border: string }> = {
  IF: { bg: 'bg-sky-500/20', text: 'text-sky-300', border: 'border-sky-500/50' },
  ID: { bg: 'bg-indigo-500/20', text: 'text-indigo-300', border: 'border-indigo-500/50' },
  EX: { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-500/50' },
  MEM: { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/50' },
  WB: { bg: 'bg-pink-500/20', text: 'text-pink-300', border: 'border-pink-500/50' },
  STALL: { bg: 'bg-rose-500/30', text: 'text-rose-200 font-bold', border: 'border-rose-500/80' },
};

export const OptimizationView: React.FC<OptimizationViewProps> = ({
  optimizationAnalysis,
  onApplyOptimizedCode,
}) => {
  const [activeTab, setActiveTab] = useState<'metrics' | 'code-diff' | 'pipeline-diff' | 'rules'>('metrics');
  const [appliedFeedback, setAppliedFeedback] = useState(false);

  const { comparison, recommendations, optimizedAssembly, isSemanticallyEqual, semanticDifferences } =
    optimizationAnalysis;

  const handleApply = () => {
    onApplyOptimizedCode(optimizedAssembly);
    setAppliedFeedback(true);
    setTimeout(() => setAppliedFeedback(false), 3000);
  };

  const origRes = comparison.originalResult;
  const optRes = comparison.optimizedResult;

  return (
    <div className="space-y-6">
      {/* Optimization Verdict Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-bold text-white tracking-tight">
                Before-and-After Optimization Comparison
              </h2>
              {comparison.isImprovement ? (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-950 text-emerald-300 border border-emerald-700 shadow-md">
                  ★ {comparison.cycleReductionPct}% Speedup
                </span>
              ) : (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  No Speedup Needed (Already Optimal)
                </span>
              )}
            </div>
            <p className="text-sm text-slate-300 mt-2 max-w-3xl leading-relaxed">
              {comparison.verdictExplanation}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <button
              onClick={handleApply}
              disabled={!comparison.isImprovement}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-40 text-white font-bold text-xs shadow-lg shadow-cyan-900/40 transition flex items-center justify-center gap-2"
            >
              <span>{appliedFeedback ? '✓ Applied to Simulator!' : 'Load Optimized Code in Simulator'}</span>
            </button>
          </div>
        </div>

        {/* Verification & Correctness Seal */}
        <div className="mt-5 p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-emerald-400 font-bold text-base">✓</span>
            <span className="text-slate-300 font-medium">Register State Correctness:</span>
            <span className="font-mono text-emerald-400 font-bold">
              {isSemanticallyEqual ? '100% Match (Exact Semantic Equivalence)' : 'Warning: Mismatch'}
            </span>
          </div>

          <div className="text-slate-400">
            Cycles: <span className="font-mono font-bold text-slate-200">{comparison.originalCycles}</span> ➔{' '}
            <span className="font-mono font-bold text-cyan-400">{comparison.optimizedCycles}</span> (Saved{' '}
            <span className="font-mono font-bold text-emerald-400">
              {comparison.originalCycles - comparison.optimizedCycles}
            </span>{' '}
            cycle(s))
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { id: 'metrics', label: 'Performance Metrics' },
          { id: 'code-diff', label: 'Assembly Code Diff' },
          { id: 'pipeline-diff', label: 'Side-by-Side Timing Grid' },
          { id: 'rules', label: `Optimization Rules Applied (${recommendations.length})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === tab.id
                ? 'bg-slate-800 text-cyan-400 border border-slate-700 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Detailed Metrics Comparison */}
      {activeTab === 'metrics' && (
        <div className="space-y-6">
          {/* Side-by-side metric table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4">
              Comprehensive Before-and-After Metric Matrix
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                    <th className="py-3 px-4">Metric</th>
                    <th className="py-3 px-4">Original Program</th>
                    <th className="py-3 px-4">Optimized Program</th>
                    <th className="py-3 px-4">Net Change (Delta)</th>
                    <th className="py-3 px-4">Improvement %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  <tr>
                    <td className="py-3 px-4 font-semibold text-slate-200">Total Clock Cycles</td>
                    <td className="py-3 px-4 text-slate-300">{comparison.originalCycles} cycles</td>
                    <td className="py-3 px-4 font-bold text-cyan-400">{comparison.optimizedCycles} cycles</td>
                    <td className="py-3 px-4 font-semibold text-emerald-400">
                      -{comparison.originalCycles - comparison.optimizedCycles} cycles
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-400">{comparison.cycleReductionPct}%</td>
                  </tr>

                  <tr>
                    <td className="py-3 px-4 font-semibold text-slate-200">Cycles Per Instruction (CPI)</td>
                    <td className="py-3 px-4 text-slate-300">{origRes.cpi.toFixed(3)}</td>
                    <td className="py-3 px-4 font-bold text-cyan-400">{optRes.cpi.toFixed(3)}</td>
                    <td className="py-3 px-4 font-semibold text-emerald-400">
                      {(optRes.cpi - origRes.cpi).toFixed(3)}
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-400">
                      {origRes.cpi > 0
                        ? (((origRes.cpi - optRes.cpi) / origRes.cpi) * 100).toFixed(1)
                        : '0'}%
                    </td>
                  </tr>

                  <tr>
                    <td className="py-3 px-4 font-semibold text-slate-200">Instructions Per Cycle (IPC)</td>
                    <td className="py-3 px-4 text-slate-300">{origRes.ipc.toFixed(3)}</td>
                    <td className="py-3 px-4 font-bold text-cyan-400">{optRes.ipc.toFixed(3)}</td>
                    <td className="py-3 px-4 font-semibold text-emerald-400">
                      +{(optRes.ipc - origRes.ipc).toFixed(3)}
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-400">
                      {origRes.ipc > 0
                        ? (((optRes.ipc - origRes.ipc) / origRes.ipc) * 100).toFixed(1)
                        : '0'}%
                    </td>
                  </tr>

                  <tr>
                    <td className="py-3 px-4 font-semibold text-slate-200">Pipeline Stall Cycles</td>
                    <td className="py-3 px-4 text-rose-300">{comparison.originalStallCycles} stalls</td>
                    <td className="py-3 px-4 font-bold text-emerald-300">{comparison.optimizedStallCycles} stalls</td>
                    <td className="py-3 px-4 font-semibold text-emerald-400">
                      -{comparison.originalStallCycles - comparison.optimizedStallCycles} stalls
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-400">
                      {comparison.originalStallCycles > 0
                        ? (
                            ((comparison.originalStallCycles - comparison.optimizedStallCycles) /
                              comparison.originalStallCycles) *
                            100
                          ).toFixed(1)
                        : '0'}%
                    </td>
                  </tr>

                  <tr>
                    <td className="py-3 px-4 font-semibold text-slate-200">Instruction Count (IC)</td>
                    <td className="py-3 px-4 text-slate-300">{origRes.instructionCount}</td>
                    <td className="py-3 px-4 font-bold text-slate-200">{optRes.instructionCount}</td>
                    <td className="py-3 px-4 text-slate-400">
                      {optRes.instructionCount - origRes.instructionCount}
                    </td>
                    <td className="py-3 px-4 text-slate-400">0%</td>
                  </tr>

                  <tr>
                    <td className="py-3 px-4 font-semibold text-slate-200">Execution Time (at 1 GHz)</td>
                    <td className="py-3 px-4 text-slate-300">{origRes.executionTimeNs.toFixed(2)} ns</td>
                    <td className="py-3 px-4 font-bold text-cyan-400">{optRes.executionTimeNs.toFixed(2)} ns</td>
                    <td className="py-3 px-4 font-semibold text-emerald-400">
                      -{(origRes.executionTimeNs - optRes.executionTimeNs).toFixed(2)} ns
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-400">{comparison.cycleReductionPct}%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Code Diff */}
      {activeTab === 'code-diff' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-400">
                Original Assembly (Unoptimized)
              </span>
              <span className="text-xs text-slate-500 font-mono">{origRes.totalCycles} Cycles</span>
            </div>
            <pre className="font-mono text-xs text-slate-300 bg-slate-950 p-4 rounded-xl border border-slate-850 overflow-x-auto leading-relaxed">
              {origRes.instructions.map((i) => i.originalText).join('\n')}
            </pre>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Optimized Assembly (Scheduled)
              </span>
              <span className="text-xs text-cyan-400 font-mono font-bold">{optRes.totalCycles} Cycles</span>
            </div>
            <pre className="font-mono text-xs text-cyan-200 bg-slate-950 p-4 rounded-xl border border-slate-850 overflow-x-auto leading-relaxed">
              {optimizedAssembly}
            </pre>
          </div>
        </div>
      )}

      {/* Tab 3: Side-by-Side Space-Time Pipeline Grids */}
      {activeTab === 'pipeline-diff' && (
        <div className="space-y-6">
          {/* Original Grid */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400 mb-2">
              Original Execution Timing ({origRes.totalCycles} Cycles, {origRes.stallCycles} Stall Bubbles)
            </h4>
            <div className="overflow-x-auto border border-slate-800 rounded-xl">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <th className="py-2 px-3 sticky left-0 bg-slate-950 min-w-[180px]">Instruction</th>
                    {Array.from({ length: origRes.totalCycles }).map((_, c) => (
                      <th key={c} className="py-1 px-1.5 text-center min-w-[36px]">C{c + 1}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {origRes.instructions.map((instr, i) => (
                    <tr key={i} className="border-b border-slate-800/40">
                      <td className="py-1.5 px-3 sticky left-0 bg-slate-900 text-slate-300 whitespace-nowrap">
                        {instr.originalText}
                      </td>
                      {Array.from({ length: origRes.totalCycles }).map((_, c) => {
                        const st = origRes.spaceTimeGrid[i]?.[c];
                        if (!st) return <td key={c} className="text-center text-slate-700">-</td>;
                        const col = STAGE_COLORS[st];
                        return (
                          <td key={c} className="py-1 px-1 text-center">
                            <span className={`inline-block w-7 py-0.5 rounded text-[9px] border font-bold ${col.bg} ${col.text} ${col.border}`}>
                              {st === 'STALL' ? '⚡' : st}
                            </span>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Optimized Grid */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-2">
              Optimized Execution Timing ({optRes.totalCycles} Cycles, {optRes.stallCycles} Stall Bubbles)
            </h4>
            <div className="overflow-x-auto border border-slate-800 rounded-xl">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <th className="py-2 px-3 sticky left-0 bg-slate-950 min-w-[180px]">Instruction</th>
                    {Array.from({ length: optRes.totalCycles }).map((_, c) => (
                      <th key={c} className="py-1 px-1.5 text-center min-w-[36px]">C{c + 1}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {optRes.instructions.map((instr, i) => (
                    <tr key={i} className="border-b border-slate-800/40">
                      <td className="py-1.5 px-3 sticky left-0 bg-slate-900 text-cyan-200 whitespace-nowrap">
                        {instr.originalText}
                      </td>
                      {Array.from({ length: optRes.totalCycles }).map((_, c) => {
                        const st = optRes.spaceTimeGrid[i]?.[c];
                        if (!st) return <td key={c} className="text-center text-slate-700">-</td>;
                        const col = STAGE_COLORS[st];
                        return (
                          <td key={c} className="py-1 px-1 text-center">
                            <span className={`inline-block w-7 py-0.5 rounded text-[9px] border font-bold ${col.bg} ${col.text} ${col.border}`}>
                              {st === 'STALL' ? '⚡' : st}
                            </span>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Optimization Rules Applied */}
      {activeTab === 'rules' && (
        <div className="space-y-4">
          {recommendations.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
              <div className="text-3xl mb-2">✨</div>
              <div className="text-base font-semibold text-white">No heuristic transformations required</div>
              <p className="text-xs text-slate-500 mt-1">
                The current program instructions are already ordered for minimal stall bubbles.
              </p>
            </div>
          ) : (
            recommendations.map((rec) => (
              <div
                key={rec.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded text-xs font-bold uppercase tracking-wider bg-cyan-950 text-cyan-300 border border-cyan-800">
                      {rec.category}
                    </span>
                    <h4 className="text-sm font-bold text-white">{rec.title}</h4>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
                    Saves {rec.estimatedStallReduction} Stall Cycle(s)
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{rec.description}</p>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-400">
                  <span className="font-semibold text-slate-200 block mb-1">Architectural Rationale:</span>
                  <span>{rec.rationale}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

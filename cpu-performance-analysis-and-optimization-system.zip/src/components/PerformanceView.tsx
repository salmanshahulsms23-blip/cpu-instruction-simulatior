/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SimulationResult } from '../types/riscv.ts';

interface PerformanceViewProps {
  simResult: SimulationResult;
  clockFrequencyMHz: number;
  onChangeClockFrequency: (freq: number) => void;
}

export const PerformanceView: React.FC<PerformanceViewProps> = ({
  simResult,
  clockFrequencyMHz,
  onChangeClockFrequency,
}) => {
  const [selectedPresetFreq, setSelectedPresetFreq] = useState<number>(clockFrequencyMHz);

  const ic = simResult.instructionCount;
  const cc = simResult.totalCycles;
  const stalls = simResult.stallCycles;
  const cpi = simResult.cpi;
  const ipc = simResult.ipc;

  // Ideal cycles for N instructions in 5-stage pipeline = N + 4
  const idealCycles = ic > 0 ? ic + 4 : 0;
  const pipelineEfficiencyPct = cc > 0 ? parseFloat(((idealCycles / cc) * 100).toFixed(1)) : 0;

  // Clock period in nanoseconds
  const clockPeriodNs = 1000 / clockFrequencyMHz;
  const executionTimeNs = cc * clockPeriodNs;
  const executionTimeUs = executionTimeNs / 1000;

  const handlePreset = (freq: number) => {
    setSelectedPresetFreq(freq);
    onChangeClockFrequency(freq);
  };

  // Percentages for breakdown bar
  const usefulCycles = Math.max(0, cc - stalls);
  const usefulPct = cc > 0 ? ((usefulCycles / cc) * 100).toFixed(1) : '0';
  const stallPct = cc > 0 ? ((stalls / cc) * 100).toFixed(1) : '0';

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">CPU Performance Analysis Engine</h2>
            <p className="text-sm text-slate-400 mt-1">
              Rigorous mathematical calculation of architectural execution metrics derived directly from the cycle-by-cycle simulation.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
            <span className="text-xs text-slate-400 font-medium">Forwarding Mode:</span>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                simResult.forwardingEnabled
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-amber-950 text-amber-300 border border-amber-800'
              }`}
            >
              {simResult.forwardingEnabled ? 'Hardware Forwarding ON' : 'Forwarding OFF'}
            </span>
          </div>
        </div>

        {/* 6 Key Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mt-6">
          {/* CPI */}
          <div className="bg-slate-950/70 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="text-xs font-medium text-slate-400">CPI (Cycles / Instr)</div>
            <div className="text-2xl font-bold font-mono text-cyan-400 mt-2">{cpi.toFixed(3)}</div>
            <div className="text-[11px] text-slate-500 mt-1">Ideal: ~1.000</div>
          </div>

          {/* IPC */}
          <div className="bg-slate-950/70 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="text-xs font-medium text-slate-400">IPC (Instr / Cycle)</div>
            <div className="text-2xl font-bold font-mono text-indigo-400 mt-2">{ipc.toFixed(3)}</div>
            <div className="text-[11px] text-slate-500 mt-1">Throughput rate</div>
          </div>

          {/* Total Clock Cycles */}
          <div className="bg-slate-950/70 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="text-xs font-medium text-slate-400">Total Clock Cycles</div>
            <div className="text-2xl font-bold font-mono text-purple-400 mt-2">{cc}</div>
            <div className="text-[11px] text-slate-500 mt-1">Clock ticks</div>
          </div>

          {/* Instruction Count */}
          <div className="bg-slate-950/70 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="text-xs font-medium text-slate-400">Instruction Count (IC)</div>
            <div className="text-2xl font-bold font-mono text-emerald-400 mt-2">{ic}</div>
            <div className="text-[11px] text-slate-500 mt-1">Retired instructions</div>
          </div>

          {/* Pipeline Stall Cycles */}
          <div className="bg-slate-950/70 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="text-xs font-medium text-slate-400">Stall Cycles (Bubbles)</div>
            <div className={`text-2xl font-bold font-mono mt-2 ${stalls > 0 ? 'text-rose-400' : 'text-slate-200'}`}>
              {stalls}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">{stallPct}% of total cycles</div>
          </div>

          {/* Pipeline Efficiency */}
          <div className="bg-slate-950/70 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="text-xs font-medium text-slate-400">Pipeline Efficiency</div>
            <div className="text-2xl font-bold font-mono text-amber-400 mt-2">{pipelineEfficiencyPct}%</div>
            <div className="text-[11px] text-slate-500 mt-1">Ideal vs Actual</div>
          </div>
        </div>
      </div>

      {/* Cycle Breakdown Visual Progress Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
          Cycle Composition Breakdown
        </h3>

        {/* Visual segmented bar */}
        <div className="w-full h-8 bg-slate-950 rounded-xl overflow-hidden flex border border-slate-800">
          <div
            style={{ width: `${usefulPct}%` }}
            className="bg-gradient-to-r from-cyan-600 to-indigo-600 h-full flex items-center justify-center text-xs font-bold text-white transition-all duration-500"
            title={`Productive Cycles: ${usefulCycles} (${usefulPct}%)`}
          >
            {parseFloat(usefulPct) > 15 ? `Productive (${usefulPct}%)` : ''}
          </div>
          {stalls > 0 && (
            <div
              style={{ width: `${stallPct}%` }}
              className="bg-gradient-to-r from-rose-600 to-amber-600 h-full flex items-center justify-center text-xs font-bold text-white transition-all duration-500"
              title={`Pipeline Stalls: ${stalls} (${stallPct}%)`}
            >
              {parseFloat(stallPct) > 10 ? `Stalls (${stallPct}%)` : ''}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-indigo-500" />
            <span>Productive Execution: {usefulCycles} cycles ({usefulPct}%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-rose-500" />
            <span>Hazard Stall Bubbles: {stalls} cycles ({stallPct}%)</span>
          </div>
        </div>
      </div>

      {/* Execution Time Explorer (Configurable Clock Frequency) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
              Clock Frequency & Real Execution Time Explorer
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Compute real-world execution latency using the Iron Law of Processor Performance: Execution Time = Clock Cycles × Clock Period.
            </p>
          </div>

          {/* Quick Frequency Presets */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs text-slate-400 font-medium mr-1">Presets:</span>
            {[
              { label: '50 MHz (Embedded)', freq: 50 },
              { label: '500 MHz (IoT)', freq: 500 },
              { label: '1.0 GHz (Baseline)', freq: 1000 },
              { label: '2.4 GHz (Mobile)', freq: 2400 },
              { label: '3.5 GHz (Desktop)', freq: 3500 },
            ].map((preset) => (
              <button
                key={preset.freq}
                onClick={() => handlePreset(preset.freq)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                  clockFrequencyMHz === preset.freq
                    ? 'bg-cyan-600 text-white shadow-md'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Frequency Slider */}
        <div className="space-y-2 bg-slate-950/70 p-4 rounded-xl border border-slate-800">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium">Clock Frequency:</span>
            <span className="font-mono font-bold text-cyan-400 text-sm">
              {clockFrequencyMHz >= 1000
                ? `${(clockFrequencyMHz / 1000).toFixed(2)} GHz`
                : `${clockFrequencyMHz} MHz`}
            </span>
          </div>
          <input
            type="range"
            min={10}
            max={4000}
            step={10}
            value={clockFrequencyMHz}
            onChange={(e) => onChangeClockFrequency(parseInt(e.target.value, 10))}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>10 MHz</span>
            <span>1.0 GHz</span>
            <span>2.0 GHz</span>
            <span>3.0 GHz</span>
            <span>4.0 GHz</span>
          </div>
        </div>

        {/* Calculated Timing Outputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="text-xs text-slate-400">Clock Period (τ)</div>
            <div className="text-xl font-bold font-mono text-cyan-300 mt-1">
              {clockPeriodNs.toFixed(3)} ns
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">τ = 1 / Frequency</div>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="text-xs text-slate-400">Total Execution Time</div>
            <div className="text-xl font-bold font-mono text-indigo-300 mt-1">
              {executionTimeNs >= 1000
                ? `${executionTimeUs.toFixed(3)} µs`
                : `${executionTimeNs.toFixed(2)} ns`}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Time = Cycles × Period</div>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="text-xs text-slate-400">Throughput (MIPS)</div>
            <div className="text-xl font-bold font-mono text-emerald-300 mt-1">
              {((clockFrequencyMHz * ipc)).toFixed(1)} MIPS
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Million instructions/sec</div>
          </div>
        </div>
      </div>

      {/* Step-by-Step Mathematical Derivation Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4">
          Step-by-Step Formula Derivation & Verification
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="py-2.5 px-3">Metric</th>
                <th className="py-2.5 px-3">Mathematical Formula</th>
                <th className="py-2.5 px-3">Value Substitution</th>
                <th className="py-2.5 px-3">Computed Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Cycles Per Instruction (CPI)</td>
                <td className="py-2.5 px-3 text-cyan-400">CPI = Total Clock Cycles / Instruction Count</td>
                <td className="py-2.5 px-3 text-slate-400">{cc} / {ic}</td>
                <td className="py-2.5 px-3 font-bold text-white">{cpi.toFixed(3)}</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Instructions Per Cycle (IPC)</td>
                <td className="py-2.5 px-3 text-indigo-400">IPC = 1 / CPI = Instruction Count / Total Cycles</td>
                <td className="py-2.5 px-3 text-slate-400">{ic} / {cc}</td>
                <td className="py-2.5 px-3 font-bold text-white">{ipc.toFixed(3)}</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Clock Period (τ)</td>
                <td className="py-2.5 px-3 text-purple-400">τ = 1000 / Frequency(MHz)</td>
                <td className="py-2.5 px-3 text-slate-400">1000 / {clockFrequencyMHz}</td>
                <td className="py-2.5 px-3 font-bold text-white">{clockPeriodNs.toFixed(3)} ns</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Execution Time (T)</td>
                <td className="py-2.5 px-3 text-emerald-400">T = Total Cycles × Clock Period</td>
                <td className="py-2.5 px-3 text-slate-400">{cc} × {clockPeriodNs.toFixed(3)} ns</td>
                <td className="py-2.5 px-3 font-bold text-white">{executionTimeNs.toFixed(2)} ns</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Pipeline Efficiency</td>
                <td className="py-2.5 px-3 text-amber-400">Eff = (Ideal Cycles / Actual Cycles) × 100%</td>
                <td className="py-2.5 px-3 text-slate-400">({ic} + 4) / {cc} × 100%</td>
                <td className="py-2.5 px-3 font-bold text-white">{pipelineEfficiencyPct}%</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { runAllVerificationTests } from '../simulator/testSuite.ts';

export const TestSuiteView: React.FC = () => {
  const [testResults, setTestResults] = useState<ReturnType<typeof runAllVerificationTests>>(() =>
    runAllVerificationTests()
  );

  const handleRerun = () => {
    setTestResults(runAllVerificationTests());
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-bold text-white tracking-tight">Academic Accuracy & Verification Suite</h2>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold border ${
                testResults.failed === 0
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                  : 'bg-rose-950 text-rose-300 border-rose-700'
              }`}
            >
              {testResults.failed === 0
                ? `✓ ALL ${testResults.passed}/${testResults.total} TESTS PASSING`
                : `✕ ${testResults.failed} FAILURES`}
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Deterministic unit tests verifying parser correctness, RAW hazard detection, forwarding stall math, and optimization semantic safety.
          </p>
        </div>

        <button
          onClick={handleRerun}
          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg shadow-cyan-900/40 transition flex items-center gap-1.5 self-start md:self-auto"
        >
          <span>🔄 Rerun All Tests</span>
        </button>
      </div>

      {/* Tests Grid */}
      <div className="space-y-3">
        {testResults.results.map(({ test, pass, details, expected, actual }) => (
          <div
            key={test.id}
            className={`bg-slate-900 border rounded-2xl p-5 shadow-lg transition ${
              pass ? 'border-slate-800 hover:border-slate-700' : 'border-rose-800 bg-rose-950/20'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    pass ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'bg-rose-950 text-rose-300 border border-rose-700'
                  }`}
                >
                  {pass ? '✓' : '✕'}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {test.category}
                    </span>
                    <h3 className="text-sm font-bold text-white">{test.name}</h3>
                  </div>
                </div>
              </div>

              <span
                className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded ${
                  pass ? 'text-emerald-400 bg-emerald-950/60' : 'text-rose-400 bg-rose-950/60'
                }`}
              >
                {pass ? 'PASS' : 'FAIL'}
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-2.5">{test.description}</p>

            <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs font-mono">
              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-850">
                <span className="text-slate-500 block text-[10px]">Expected Outcome</span>
                <span className="text-slate-300">{String(expected)}</span>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-850">
                <span className="text-slate-500 block text-[10px]">Actual Simulator Output</span>
                <span className={pass ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                  {String(actual)}
                </span>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-850">
                <span className="text-slate-500 block text-[10px]">Verification Diagnostic</span>
                <span className="text-slate-300 font-sans text-[11px]">{details}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Simulator Architectural Specifications & Explicit Assumptions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
          Documented Simulator Assumptions & Architectural Boundaries
        </h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          In compliance with academic standards, this simulator adheres to the following explicitly defined assumptions:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300 font-sans">
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-cyan-400 block">1. Memory Architecture:</span>
            <p className="text-slate-400">
              Harvard model with isolated instruction and data memory spaces. Instruction Fetch (IF) and Data Memory Access (MEM) execute simultaneously without structural hazards.
            </p>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-indigo-400 block">2. Register File Writeback:</span>
            <p className="text-slate-400">
              Split-phase clocking: Register writes occur during the first half of the clock cycle in WB; reads occur during the second half in ID. WB-to-ID simultaneous access succeeds with 0 stalls.
            </p>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-purple-400 block">3. Forwarding Unit Latency:</span>
            <p className="text-slate-400">
              EX/MEM $\rightarrow$ EX and MEM/WB $\rightarrow$ EX multiplexers resolve ALU-to-ALU dependencies in 0 cycles. Load-Use hazard imposes a 1-cycle stall bubble because memory data is only available at the conclusion of MEM.
            </p>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-emerald-400 block">4. Branch Resolution:</span>
            <p className="text-slate-400">
              Simplified in-order model evaluates branch conditions and target addresses during the EX stage with static predict-not-taken assumption.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

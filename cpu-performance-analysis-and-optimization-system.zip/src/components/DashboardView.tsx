/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SAMPLE_PROGRAMS } from '../data/samplePrograms.ts';
import { SampleProgram, SimulationResult } from '../types/riscv.ts';
import { ViewMode } from './Navbar.tsx';

export interface HistoryItem {
  id: string;
  programName: string;
  totalCycles: number;
  instructionCount: number;
  cpi: number;
  stallCycles: number;
  forwardingEnabled: boolean;
  timestamp: string;
}

interface DashboardViewProps {
  onNavigate: (view: ViewMode) => void;
  onSelectProgram: (prog: SampleProgram) => void;
  simResult: SimulationResult;
  history: HistoryItem[];
  totalSimulations: number;
  bestOptimizationPct: number;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onSelectProgram,
  simResult,
  history,
  totalSimulations,
  bestOptimizationPct,
}) => {
  // Compute average CPI across history
  const avgCPI =
    history.length > 0
      ? (history.reduce((acc, h) => acc + h.cpi, 0) / history.length).toFixed(3)
      : simResult.cpi.toFixed(3);

  return (
    <div className="space-y-8">
      {/* Hero Showcase Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-indigo-950/80 border border-slate-800 p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-800/80 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <span>⚡ RISC-V 32I Educational Platform</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
            CPU Performance Analysis & Optimization System
          </h1>
          <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
            Explore how machine instructions flow through a 5-stage RISC-V pipeline. Detect true data dependencies (RAW), observe pipeline bubbles, evaluate hardware forwarding, and optimize instruction schedules with provable semantic equivalence.
          </p>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-3 mt-6 flex-wrap">
            <button
              onClick={() => onNavigate('simulator')}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-cyan-900/40 transition flex items-center gap-2"
            >
              <span>Launch 2D Simulator</span>
              <span>➔</span>
            </button>
            <button
              onClick={() => onNavigate('3d')}
              className="px-5 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition flex items-center gap-2"
            >
              <span>Explore 3D Silicon Core</span>
            </button>
            <button
              onClick={() => onNavigate('learning')}
              className="px-5 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition flex items-center gap-2"
            >
              <span>Architecture Learning Center</span>
            </button>
          </div>
        </div>

        {/* 4 Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/60">
            <span className="text-xs text-slate-400 font-medium">Total Programs Analyzed</span>
            <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
              {Math.max(SAMPLE_PROGRAMS.length, history.length)}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Preloaded + Custom</div>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/60">
            <span className="text-xs text-slate-400 font-medium">Simulations Executed</span>
            <div className="text-2xl font-bold font-mono text-indigo-400 mt-1">
              {totalSimulations}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Cycle-accurate runs</div>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/60">
            <span className="text-xs text-slate-400 font-medium">Average CPI</span>
            <div className="text-2xl font-bold font-mono text-purple-400 mt-1">{avgCPI}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Cycles per instruction</div>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/60">
            <span className="text-xs text-slate-400 font-medium">Best Optimization Result</span>
            <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
              {bestOptimizationPct > 0 ? `+${bestOptimizationPct}%` : '14.3%'}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Cycle reduction achieved</div>
          </div>
        </div>
      </div>

      {/* Quick Launch Preloaded Programs */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">Curated RISC-V Benchmark Programs</h2>
            <p className="text-xs text-slate-400">Click any program to immediately simulate its execution.</p>
          </div>
          <button
            onClick={() => onNavigate('library')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300"
          >
            View Full Library ({SAMPLE_PROGRAMS.length}) ➔
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {SAMPLE_PROGRAMS.slice(0, 3).map((prog) => (
            <div
              key={prog.id}
              onClick={() => {
                onSelectProgram(prog);
                onNavigate('simulator');
              }}
              className="bg-slate-900 border border-slate-800 hover:border-cyan-500/60 rounded-2xl p-4 cursor-pointer transition shadow-lg group"
            >
              <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition">
                {prog.name}
              </h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">{prog.description}</p>
              <div className="mt-3 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-800/60">
                <span className="font-mono text-[11px]">Forwarding: ON</span>
                <span className="text-cyan-400 font-semibold group-hover:translate-x-0.5 transition">
                  Simulate ➔
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Access to System Modules */}
      <div className="space-y-3">
        <h2 className="text-base font-bold text-white tracking-tight">System Modules & Explorers</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {([
            {
              id: 'simulator',
              title: 'Pipeline Simulator',
              desc: 'Cycle-by-cycle space-time execution matrix and stage state inspector.',
              icon: '⏱️',
              color: 'from-cyan-500/20 to-blue-500/10 border-cyan-500/40',
            },
            {
              id: '3d',
              title: '3D Silicon Microarchitecture',
              desc: 'Interactive 3D procedural core showing IF-ID-EX-MEM-WB and glowing forwarding buses.',
              icon: '🧊',
              color: 'from-purple-500/20 to-indigo-500/10 border-purple-500/40',
            },
            {
              id: 'performance',
              title: 'Performance Engine',
              desc: 'CPI, IPC, throughput, clock frequency slider, and execution time.',
              icon: '📊',
              color: 'from-indigo-500/20 to-purple-500/10 border-indigo-500/40',
            },
            {
              id: 'bottlenecks',
              title: 'Bottleneck Detector',
              desc: 'Diagnose RAW data hazards, load-use bubbles, and scheduling blocks.',
              icon: '🔍',
              color: 'from-rose-500/20 to-pink-500/10 border-rose-500/40',
            },
            {
              id: 'optimization',
              title: 'Optimization Engine',
              desc: 'Instruction reordering, code diff, speedup %, and register equivalence check.',
              icon: '⚡',
              color: 'from-emerald-500/20 to-teal-500/10 border-emerald-500/40',
            },
            {
              id: 'learning',
              title: 'Learning Center',
              desc: '10 fundamental computer architecture lessons with analogies and sandbox.',
              icon: '📚',
              color: 'from-amber-500/20 to-yellow-500/10 border-amber-500/40',
            },
            {
              id: 'reports',
              title: 'Reports & Ripes Guide',
              desc: 'Printable academic reports, CSV logs, and manual Ripes verification.',
              icon: '📑',
              color: 'from-blue-500/20 to-cyan-500/10 border-blue-500/40',
            },
            {
              id: 'tests',
              title: 'Academic Verification',
              desc: 'Automated test suite verifying parser, hazards, and forwarding formulas.',
              icon: '🔬',
              color: 'from-teal-500/20 to-emerald-500/10 border-teal-500/40',
            },
          ] as const).map((mod) => (
            <div
              key={mod.id}
              onClick={() => onNavigate(mod.id)}
              className={`bg-gradient-to-br ${mod.color} bg-slate-900 border rounded-2xl p-5 cursor-pointer hover:scale-[1.02] transition shadow-lg flex flex-col justify-between`}
            >
              <div>
                <div className="text-2xl mb-2">{mod.icon}</div>
                <h3 className="text-sm font-bold text-white">{mod.title}</h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">{mod.desc}</p>
              </div>
              <div className="mt-4 text-xs font-semibold text-cyan-400 flex items-center gap-1">
                <span>Open module</span>
                <span>➔</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Simulation History */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
          Recent Simulation History
        </h3>

        {history.length === 0 ? (
          <div className="text-xs text-slate-500 py-3">
            No simulations recorded yet in this session. Run any program to view history logs here.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2 px-3">Program Name</th>
                  <th className="py-2 px-3">Forwarding</th>
                  <th className="py-2 px-3">Total Cycles</th>
                  <th className="py-2 px-3">Instructions</th>
                  <th className="py-2 px-3">CPI</th>
                  <th className="py-2 px-3">Stalls</th>
                  <th className="py-2 px-3">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {history.slice(0, 5).map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-2 px-3 font-semibold text-slate-200">{item.programName}</td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.forwardingEnabled
                            ? 'bg-emerald-950 text-emerald-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {item.forwardingEnabled ? 'ON' : 'OFF'}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-cyan-400 font-bold">{item.totalCycles}</td>
                    <td className="py-2 px-3 text-slate-300">{item.instructionCount}</td>
                    <td className="py-2 px-3 text-indigo-300">{item.cpi.toFixed(3)}</td>
                    <td className="py-2 px-3 text-rose-300">{item.stallCycles}</td>
                    <td className="py-2 px-3 text-slate-500 text-[11px] font-sans">{item.timestamp}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BottleneckItem, ComparisonMetrics, SimulationResult } from '../types/riscv.ts';

interface ReportsViewProps {
  simResult: SimulationResult;
  comparison: ComparisonMetrics;
  bottlenecks: BottleneckItem[];
  programName: string;
  clockFrequencyMHz: number;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  simResult,
  comparison,
  bottlenecks,
  programName,
  clockFrequencyMHz,
}) => {
  const [ripesCopied, setRipesCopied] = useState(false);

  // Generate CSV download
  const handleExportCSV = () => {
    let csv = `Cycle,IF,ID,EX,MEM,WB,Stall\n`;
    simResult.cycleSnapshots.forEach((snap) => {
      const ifText = snap.stages.IF ? snap.stages.IF.mnemonic.replace(/,/g, ';') : '-';
      const idText = snap.stages.ID ? snap.stages.ID.mnemonic.replace(/,/g, ';') : '-';
      const exText = snap.stages.EX ? snap.stages.EX.mnemonic.replace(/,/g, ';') : '-';
      const memText = snap.stages.MEM ? snap.stages.MEM.mnemonic.replace(/,/g, ';') : '-';
      const wbText = snap.stages.WB ? snap.stages.WB.mnemonic.replace(/,/g, ';') : '-';
      const stall = snap.stallOccurred ? 'YES' : 'NO';
      csv += `${snap.cycle},"${ifText}","${idText}","${exText}","${memText}","${wbText}",${stall}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `cpu_pipeline_${programName.toLowerCase().replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Generate JSON config & state download
  const handleExportJSON = () => {
    const reportData = {
      project: 'CPU Performance Analysis and Optimization System',
      programName,
      timestamp: new Date().toISOString(),
      cpuConfig: {
        architecture: 'RISC-V 32I (RV32I)',
        pipelineStages: ['IF', 'ID', 'EX', 'MEM', 'WB'],
        forwardingEnabled: simResult.forwardingEnabled,
        clockFrequencyMHz,
        clockPeriodNs: simResult.clockPeriodNs,
      },
      instructions: simResult.instructions.map((i) => i.originalText),
      metrics: {
        instructionCount: simResult.instructionCount,
        totalCycles: simResult.totalCycles,
        cpi: simResult.cpi,
        ipc: simResult.ipc,
        stallCycles: simResult.stallCycles,
        executionTimeNs: simResult.executionTimeNs,
      },
      bottlenecks: bottlenecks.map((b) => ({
        type: b.type,
        severity: b.severity,
        title: b.title,
        technical: b.technicalExplanation,
      })),
      optimization: {
        isImprovement: comparison.isImprovement,
        cycleReductionPct: comparison.cycleReductionPct,
        originalCycles: comparison.originalCycles,
        optimizedCycles: comparison.optimizedCycles,
      },
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `cpu_analysis_report_${programName.toLowerCase().replace(/\s+/g, '_')}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyRipes = () => {
    const asm = simResult.instructions.map((i) => i.originalText).join('\n');
    navigator.clipboard.writeText(asm);
    setRipesCopied(true);
    setTimeout(() => setRipesCopied(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header & Export Actions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Academic Simulation & Analysis Reports</h2>
          <p className="text-sm text-slate-400 mt-1">
            Generate printable PDF reports, export cycle-by-cycle CSV timing logs, and export JSON benchmarks.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition border border-slate-700 flex items-center gap-1.5"
          >
            <span>📥 Export CSV</span>
          </button>
          <button
            onClick={handleExportJSON}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition border border-slate-700 flex items-center gap-1.5"
          >
            <span>💾 Export JSON</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-cyan-900/40 transition flex items-center gap-1.5"
          >
            <span>🖨️ Print / Save as PDF</span>
          </button>
        </div>
      </div>

      {/* Formatted Report Card (Printable) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl space-y-6 print:bg-white print:text-black print:border-none print:shadow-none">
        {/* Document Header */}
        <div className="border-b border-slate-800 print:border-slate-300 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs font-mono font-bold text-cyan-400 print:text-blue-700 uppercase tracking-wider">
              B.Tech Computer Architecture Evaluation Report
            </span>
            <h1 className="text-2xl font-bold text-white print:text-black mt-1">
              CPU Performance Analysis & Optimization
            </h1>
            <p className="text-xs text-slate-400 print:text-slate-600 mt-0.5">
              Program: <strong className="text-white print:text-black">{programName}</strong> | Date:{' '}
              {new Date().toLocaleDateString()}
            </p>
          </div>

          <div className="text-right font-mono text-xs text-slate-400 print:text-slate-600">
            <div>Target: RISC-V 32I (RV32I)</div>
            <div>5-Stage Pipeline Core</div>
            <div>Forwarding: {simResult.forwardingEnabled ? 'Active' : 'Disabled'}</div>
          </div>
        </div>

        {/* Section 1: Executive Summary */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 print:text-slate-800">
            1. Executive Performance Summary
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div className="p-3 bg-slate-950 print:bg-slate-100 rounded-xl border border-slate-800 print:border-slate-300">
              <span className="text-slate-400 print:text-slate-600 block text-[10px]">Instruction Count</span>
              <span className="text-base font-bold text-white print:text-black">{simResult.instructionCount}</span>
            </div>
            <div className="p-3 bg-slate-950 print:bg-slate-100 rounded-xl border border-slate-800 print:border-slate-300">
              <span className="text-slate-400 print:text-slate-600 block text-[10px]">Total Clock Cycles</span>
              <span className="text-base font-bold text-cyan-400 print:text-blue-700">{simResult.totalCycles}</span>
            </div>
            <div className="p-3 bg-slate-950 print:bg-slate-100 rounded-xl border border-slate-800 print:border-slate-300">
              <span className="text-slate-400 print:text-slate-600 block text-[10px]">CPI (Cycles / Instr)</span>
              <span className="text-base font-bold text-white print:text-black">{simResult.cpi.toFixed(3)}</span>
            </div>
            <div className="p-3 bg-slate-950 print:bg-slate-100 rounded-xl border border-slate-800 print:border-slate-300">
              <span className="text-slate-400 print:text-slate-600 block text-[10px]">Stall Cycles</span>
              <span className="text-base font-bold text-rose-400 print:text-red-700">{simResult.stallCycles}</span>
            </div>
          </div>
        </div>

        {/* Section 2: Assembly Code Listing */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 print:text-slate-800">
            2. Assembly Instruction Stream
          </h3>
          <pre className="p-4 bg-slate-950 print:bg-slate-100 rounded-xl border border-slate-800 print:border-slate-300 font-mono text-xs text-slate-200 print:text-slate-900 overflow-x-auto leading-relaxed">
            {simResult.instructions.map((i, idx) => `[0x${(idx * 4).toString(16).padStart(4, '0')}]  ${i.originalText}`).join('\n')}
          </pre>
        </div>

        {/* Section 3: Bottleneck Diagnosis */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 print:text-slate-800">
            3. Hazard & Bottleneck Diagnosis ({bottlenecks.length} Items)
          </h3>
          <div className="space-y-2">
            {bottlenecks.map((b) => (
              <div
                key={b.id}
                className="p-3 bg-slate-950 print:bg-slate-50 rounded-xl border border-slate-800 print:border-slate-300 text-xs"
              >
                <div className="flex items-center justify-between font-bold text-slate-200 print:text-black">
                  <span>{b.title}</span>
                  <span className="uppercase text-[10px] text-cyan-400 print:text-blue-700">{b.severity}</span>
                </div>
                <p className="text-slate-400 print:text-slate-700 mt-1">{b.technicalExplanation}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Section 4: Before & After Optimization */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 print:text-slate-800">
            4. Before-and-After Optimization Comparison
          </h3>
          <div className="p-4 bg-slate-950 print:bg-slate-100 rounded-xl border border-slate-800 print:border-slate-300 text-xs space-y-2 font-mono">
            <div className="flex justify-between">
              <span>Original Cycles: {comparison.originalCycles}</span>
              <span>Optimized Cycles: {comparison.optimizedCycles}</span>
              <span className="font-bold text-emerald-400 print:text-green-700">
                Speedup: {comparison.cycleReductionPct}%
              </span>
            </div>
            <div className="text-slate-400 print:text-slate-700 font-sans text-xs">
              {comparison.verdictExplanation}
            </div>
          </div>
        </div>

        {/* Section 5: Academic Conclusion */}
        <div className="space-y-1 text-xs text-slate-300 print:text-slate-800">
          <h3 className="font-bold uppercase tracking-wider text-slate-300 print:text-slate-800 mb-1">
            5. Architectural Conclusion
          </h3>
          <p className="leading-relaxed">
            The simulation demonstrates that hardware forwarding and compiler instruction scheduling significantly reduce pipeline bubbles. In a classic 5-stage RISC pipeline, true data dependencies (RAW) without forwarding impose substantial cycle overheads (2 cycles per dependent ALU pair). Reordering independent instructions successfully fills the load-use delay slot, maximizing instruction throughput while guaranteeing 100% computational correctness.
          </p>
        </div>
      </div>

      {/* Section 6: Ripes External Verification Workflow */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-lg">🔬</span>
            <h3 className="text-base font-bold text-white">
              Ripes RISC-V Simulator Verification Workflow
            </h3>
          </div>

          <button
            onClick={handleCopyRipes}
            className="px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition"
          >
            {ripesCopied ? '✓ Copied Assembly!' : 'Copy Assembly for Ripes'}
          </button>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Ripes is an open-source visual computer architecture simulator for the RISC-V instruction set. You can independently verify this system's cycle counts, pipeline execution, and stall calculations by following this 4-step workflow:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-cyan-400">Step 1: Open Ripes</span>
            <p className="text-slate-400">
              Download Ripes or open web Ripes. Select processor model: <strong>5-Stage Processor with Hazard/Forwarding Unit</strong>.
            </p>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-indigo-400">Step 2: Paste Assembly</span>
            <p className="text-slate-400">
              Click &quot;Copy Assembly for Ripes&quot; above and paste into the Ripes Editor tab.
            </p>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-purple-400">Step 3: Step & Observe</span>
            <p className="text-slate-400">
              Step through the clock cycles. Compare the instruction occupying IF, ID, EX, MEM, WB with our space-time grid.
            </p>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-emerald-400">Step 4: Verify Metrics</span>
            <p className="text-slate-400">
              Verify that the total cycle count, stall bubbles, and retired instructions exactly match this tool&apos;s simulation results.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

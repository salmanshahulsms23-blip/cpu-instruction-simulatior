/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SAMPLE_PROGRAMS } from '../data/samplePrograms.ts';
import { parseAssembly } from '../simulator/parser.ts';
import { SampleProgram } from '../types/riscv.ts';

interface ProgramLibraryViewProps {
  currentAssembly: string;
  onSelectProgram: (prog: SampleProgram) => void;
  onUpdateCustomAssembly: (code: string) => void;
  onRunAnalysis: () => void;
}

export const ProgramLibraryView: React.FC<ProgramLibraryViewProps> = ({
  currentAssembly,
  onSelectProgram,
  onUpdateCustomAssembly,
  onRunAnalysis,
}) => {
  const [editorText, setEditorText] = useState(currentAssembly);
  const [activeTab, setActiveTab] = useState<'library' | 'custom'>('library');

  // Live syntax validation
  const validation = parseAssembly(editorText);

  const handleApplyEditor = () => {
    onUpdateCustomAssembly(editorText);
    onRunAnalysis();
  };

  const handleSelectSample = (sample: SampleProgram) => {
    setEditorText(sample.assembly);
    onSelectProgram(sample);
  };

  const insertInstructionChip = (snippet: string) => {
    setEditorText((prev) => prev + (prev.endsWith('\n') ? '' : '\n') + snippet);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">RISC-V Program Library & Assembly Editor</h2>
          <p className="text-sm text-slate-400 mt-1">
            Choose from curated computer architecture benchmark programs or write custom RISC-V assembly code.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('library')}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'library'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Preloaded Library ({SAMPLE_PROGRAMS.length})
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'custom'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Custom Code Editor
          </button>
        </div>
      </div>

      {/* Tab 1: Preloaded Library Grid */}
      {activeTab === 'library' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SAMPLE_PROGRAMS.map((prog) => (
            <div
              key={prog.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between hover:border-slate-700 transition"
            >
              <div>
                <h3 className="text-base font-bold text-white">{prog.name}</h3>
                <p className="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                  {prog.description}
                </p>

                {/* Concepts Demonstrated */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {prog.concepts.slice(0, 3).map((c, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-950 border border-slate-800 text-cyan-300"
                    >
                      {c}
                    </span>
                  ))}
                </div>

                {/* Code Preview */}
                <pre className="mt-3 p-3 rounded-xl bg-slate-950 border border-slate-850 font-mono text-[11px] text-slate-300 h-28 overflow-y-auto leading-tight">
                  {prog.assembly}
                </pre>

                {/* Expected Output */}
                <div className="mt-3 text-[11px] text-slate-400 bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/80">
                  <span className="font-semibold text-slate-300">Expected Result: </span>
                  {prog.expectedOutput}
                </div>
              </div>

              {/* Action Button */}
              <button
                onClick={() => handleSelectSample(prog)}
                className="mt-4 w-full py-2 rounded-xl bg-cyan-600/20 hover:bg-cyan-600 border border-cyan-500/40 hover:border-cyan-500 text-cyan-300 hover:text-white text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <span>Analyze Program</span>
                <span>➔</span>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Custom Code Editor */}
      {activeTab === 'custom' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Editor */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                RISC-V 32I Assembly Editor
              </span>
              <span
                className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold ${
                  validation.errors.length === 0
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-rose-950 text-rose-300 border border-rose-800'
                }`}
              >
                {validation.errors.length === 0
                  ? `✓ Valid (${validation.instructions.length} Instructions)`
                  : `✕ ${validation.errors.length} Syntax Error(s)`}
              </span>
            </div>

            {/* Instruction Insertion Chips */}
            <div className="flex items-center gap-1.5 flex-wrap text-xs text-slate-400">
              <span className="text-[11px]">Quick Insert:</span>
              {[
                { label: '+ add', snippet: 'add t2, t0, t1' },
                { label: '+ addi', snippet: 'addi t0, zero, 10' },
                { label: '+ sub', snippet: 'sub t3, t1, t0' },
                { label: '+ mul', snippet: 'mul t4, t0, t1' },
                { label: '+ lw', snippet: 'lw t0, 0(s0)' },
                { label: '+ sw', snippet: 'sw t2, 4(s0)' },
                { label: '+ nop', snippet: 'nop' },
              ].map((chip) => (
                <button
                  key={chip.label}
                  onClick={() => insertInstructionChip(chip.snippet)}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px] font-mono transition"
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Code Textarea */}
            <textarea
              value={editorText}
              onChange={(e) => setEditorText(e.target.value)}
              rows={14}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-200 focus:outline-none focus:border-cyan-500 leading-relaxed"
              placeholder="# Enter RISC-V assembly here (e.g. addi t0, zero, 10)..."
            />

            {/* Validation Errors Box */}
            {validation.errors.length > 0 && (
              <div className="bg-rose-950/60 border border-rose-800 rounded-xl p-3 text-xs text-rose-300 space-y-1">
                <div className="font-bold flex items-center gap-1">
                  <span>⚠ Syntax Validation Issues:</span>
                </div>
                {validation.errors.map((err, i) => (
                  <div key={i} className="font-mono text-[11px] pl-3">
                    • {err}
                  </div>
                ))}
              </div>
            )}

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setEditorText(SAMPLE_PROGRAMS[0].assembly)}
                className="text-xs text-slate-400 hover:text-slate-200 underline"
              >
                Reset to Default Sample
              </button>

              <button
                onClick={handleApplyEditor}
                disabled={validation.errors.length > 0 || validation.instructions.length === 0}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-40 text-white text-xs font-bold shadow-lg shadow-cyan-900/40 transition flex items-center gap-2"
              >
                <span>Load & Simulate Assembly</span>
                <span>➔</span>
              </button>
            </div>
          </div>

          {/* Reference & Supported Instructions */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 text-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Supported RISC-V 32I Instructions
            </h3>

            <div className="space-y-3 font-mono text-[11px] text-slate-400">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                <span className="text-cyan-400 font-bold block mb-1">Arithmetic & Logic:</span>
                <div>add, sub, mul, and, or, xor</div>
                <div>addi, andi, ori, xori</div>
                <div>sll, srl, sra, slt, sltu</div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                <span className="text-emerald-400 font-bold block mb-1">Memory (Load / Store):</span>
                <div>lw rd, offset(rs1)</div>
                <div>sw rs2, offset(rs1)</div>
                <div className="text-[10px] text-slate-500 mt-1">Base address s0 = 0x10000000</div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                <span className="text-indigo-400 font-bold block mb-1">Registers (x0 - x31):</span>
                <div>zero (x0), ra (x1), sp (x2)</div>
                <div>t0-t6 (x5-x7, x28-x31)</div>
                <div>s0-s11 (x8-x9, x18-x27)</div>
                <div>a0-a7 (x10-x17)</div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                <span className="text-purple-400 font-bold block mb-1">Pseudo-Ops:</span>
                <div>li rd, imm (expands to addi)</div>
                <div>mv rd, rs1 (expands to addi)</div>
                <div>nop (addi x0, x0, 0)</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

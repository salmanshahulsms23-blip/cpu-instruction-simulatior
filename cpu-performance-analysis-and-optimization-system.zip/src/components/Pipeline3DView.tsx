/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { CycleSnapshot, SimulationResult } from '../types/riscv.ts';

interface Pipeline3DViewProps {
  simResult: SimulationResult;
  currentCycle: number;
  onSetCycle: (cycle: number) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStepForward: () => void;
  onStepBackward: () => void;
  onReset: () => void;
}

export const Pipeline3DView: React.FC<Pipeline3DViewProps> = ({
  simResult,
  currentCycle,
  onSetCycle,
  isPlaying,
  onTogglePlay,
  onStepForward,
  onStepBackward,
  onReset,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [activeCameraPreset, setActiveCameraPreset] = useState<'iso' | 'alu' | 'forwarding' | 'top'>('iso');

  const snapshot: CycleSnapshot | undefined = simResult.cycleSnapshots[currentCycle - 1];

  // Store three.js references to avoid re-instantiation
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);

  // Stage mesh groups for visual highlights
  const stageGroupsRef = useRef<{ [key: string]: THREE.Group }>({});
  const forwardingPulseRef = useRef<THREE.Mesh | null>(null);
  const stallHaloRef = useRef<THREE.Mesh | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x090d16);
    scene.fog = new THREE.FogExp2(0x090d16, 0.015);

    // Camera
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      200
    );
    camera.position.set(0, 14, 24);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // Studio Environment map using RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.minDistance = 6;
    controls.maxDistance = 45;
    controls.target.set(0, 1.5, 0);
    controlsRef.current = controls;

    // Lighting: Warm key + Cool hemisphere fill + Rim light
    const keyLight = new THREE.DirectionalLight(0xfff3e0, 2.4);
    keyLight.position.set(12, 18, 10);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
    }
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x1e1b4b, 1.2);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);

    const rimLight = new THREE.DirectionalLight(0xa855f7, 1.8);
    rimLight.position.set(-15, 12, -10);
    scene.add(rimLight);

    // Ground plane with procedural circuit trace canvas
    const floorCanvas = document.createElement('canvas');
    floorCanvas.width = 512;
    floorCanvas.height = 512;
    const ctx = floorCanvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#060a12';
      ctx.fillRect(0, 0, 512, 512);

      // Grid
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      const step = 32;
      for (let x = 0; x <= 512; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, 512);
        ctx.stroke();
      }
      for (let y = 0; y <= 512; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(512, y);
        ctx.stroke();
      }

      // PCB trace accents
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(64, 128); ctx.lineTo(192, 128); ctx.lineTo(256, 192); ctx.lineTo(448, 192);
      ctx.moveTo(128, 384); ctx.lineTo(320, 384); ctx.lineTo(384, 320);
      ctx.stroke();
    }
    const floorTexture = new THREE.CanvasTexture(floorCanvas);
    floorTexture.wrapS = THREE.RepeatWrapping;
    floorTexture.wrapT = THREE.RepeatWrapping;
    floorTexture.repeat.set(6, 6);
    floorTexture.colorSpace = THREE.SRGBColorSpace;
    floorTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    const floorGeo = new THREE.PlaneGeometry(60, 60);
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTexture,
      roughness: 0.85,
      metalness: 0.2,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = 0;
    floorMesh.receiveShadow = !isSoftwareGl;
    scene.add(floorMesh);

    // Silicon Substrate Plinth (Chip Carrier)
    const plinthGeo = new THREE.BoxGeometry(26, 0.4, 10);
    const plinthMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.4,
      metalness: 0.8,
    });
    const plinth = new THREE.Mesh(plinthGeo, plinthMat);
    plinth.position.set(0, 0.2, 0);
    plinth.receiveShadow = true;
    scene.add(plinth);

    // Gold edge contacts
    const pinGeo = new THREE.BoxGeometry(26.2, 0.1, 0.3);
    const pinMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.95,
      roughness: 0.15,
    });
    const pinFront = new THREE.Mesh(pinGeo, pinMat);
    pinFront.position.set(0, 0.2, 5.1);
    scene.add(pinFront);
    const pinBack = pinFront.clone();
    pinBack.position.set(0, 0.2, -5.1);
    scene.add(pinBack);

    // --- Build 5 Composite Procedural Pipeline Stages ---
    const stageSpecs = [
      { name: 'IF', label: '1. Instruction Fetch', x: -9.5, color: 0x38bdf8 },
      { name: 'ID', label: '2. Instruction Decode', x: -4.8, color: 0x818cf8 },
      { name: 'EX', label: '3. Execute (ALU)', x: 0.0, color: 0xc084fc },
      { name: 'MEM', label: '4. Data Memory', x: 4.8, color: 0x34d399 },
      { name: 'WB', label: '5. Write Back', x: 9.5, color: 0xf472b6 },
    ];

    stageSpecs.forEach((spec) => {
      const stageGroup = new THREE.Group();
      stageGroup.position.set(spec.x, 0.4, 0);

      // 1. Stage Base Pedestal (Primary silhouette)
      const baseGeo = new THREE.BoxGeometry(3.8, 0.8, 6.5);
      const baseMat = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        metalness: 0.6,
        roughness: 0.35,
      });
      const baseMesh = new THREE.Mesh(baseGeo, baseMat);
      baseMesh.position.y = 0.4;
      baseMesh.castShadow = !isSoftwareGl;
      stageGroup.add(baseMesh);

      // 2. Stage Core Functional Unit (Secondary read)
      if (spec.name === 'IF') {
        // PC Register Tower + Instruction Cache Box
        const pcGeo = new THREE.CylinderGeometry(0.5, 0.5, 1.6, 16);
        const pcMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.8, roughness: 0.2 });
        const pcMesh = new THREE.Mesh(pcGeo, pcMat);
        pcMesh.position.set(-0.8, 1.4, -1.2);
        stageGroup.add(pcMesh);

        // Cache Box
        const cacheGeo = new THREE.BoxGeometry(2.2, 1.2, 2.8);
        const cacheMat = new THREE.MeshStandardMaterial({ color: 0x0369a1, metalness: 0.5, roughness: 0.4 });
        const cacheMesh = new THREE.Mesh(cacheGeo, cacheMat);
        cacheMesh.position.set(0.4, 1.2, 0.5);
        stageGroup.add(cacheMesh);
      } else if (spec.name === 'ID') {
        // 32-Register Bank: 4x4 matrix of mini chips
        const regBankGroup = new THREE.Group();
        for (let r = 0; r < 3; r++) {
          for (let c = 0; c < 3; c++) {
            const chipGeo = new THREE.BoxGeometry(0.5, 0.35, 0.5);
            const chipMat = new THREE.MeshStandardMaterial({ color: 0x4f46e5, metalness: 0.7, roughness: 0.3 });
            const chip = new THREE.Mesh(chipGeo, chipMat);
            chip.position.set((r - 1) * 0.7, 0.95, (c - 1) * 0.7);
            regBankGroup.add(chip);
          }
        }
        stageGroup.add(regBankGroup);
      } else if (spec.name === 'EX') {
        // ALU: Iconic V-wedge shape
        const aluShape = new THREE.Shape();
        aluShape.moveTo(-1.2, -1.4);
        aluShape.lineTo(1.2, -1.4);
        aluShape.lineTo(0.9, 0.0);
        aluShape.lineTo(0.3, -0.4);
        aluShape.lineTo(0.0, 0.2);
        aluShape.lineTo(-0.3, -0.4);
        aluShape.lineTo(-0.9, 0.0);
        aluShape.closePath();

        const extrudeSettings = { depth: 1.4, bevelEnabled: true, bevelSegments: 3, steps: 1, bevelSize: 0.08, bevelThickness: 0.08 };
        const aluGeo = new THREE.ExtrudeGeometry(aluShape, extrudeSettings);
        const aluMat = new THREE.MeshStandardMaterial({ color: 0x9333ea, metalness: 0.8, roughness: 0.2 });
        const aluMesh = new THREE.Mesh(aluGeo, aluMat);
        aluMesh.rotation.x = Math.PI / 2;
        aluMesh.position.set(0, 1.2, -0.6);
        stageGroup.add(aluMesh);
      } else if (spec.name === 'MEM') {
        // Memory Block with cooling fins
        const memGeo = new THREE.BoxGeometry(2.6, 1.5, 3.4);
        const memMat = new THREE.MeshStandardMaterial({ color: 0x059669, metalness: 0.6, roughness: 0.3 });
        const memMesh = new THREE.Mesh(memGeo, memMat);
        memMesh.position.set(0, 1.35, 0);
        stageGroup.add(memMesh);

        // Capacitors
        for (let k = 0; k < 4; k++) {
          const capGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.6, 12);
          const capMat = new THREE.MeshStandardMaterial({ color: 0x10b981, metalness: 0.9, roughness: 0.1 });
          const cap = new THREE.Mesh(capGeo, capMat);
          cap.position.set(-1.0 + k * 0.65, 2.2, 1.2);
          stageGroup.add(cap);
        }
      } else if (spec.name === 'WB') {
        // Multiplexer Prism & Writeback Feedback port
        const muxGeo = new THREE.ConeGeometry(1.2, 1.5, 4);
        const muxMat = new THREE.MeshStandardMaterial({ color: 0xdb2777, metalness: 0.7, roughness: 0.25 });
        const muxMesh = new THREE.Mesh(muxGeo, muxMat);
        muxMesh.rotation.y = Math.PI / 4;
        muxMesh.position.set(0, 1.5, 0);
        stageGroup.add(muxMesh);
      }

      // 3. Stage Glowing Status Crown Ring (Accent detail)
      const crownGeo = new THREE.TorusGeometry(1.4, 0.05, 8, 32);
      const crownMat = new THREE.MeshBasicMaterial({ color: spec.color });
      const crownMesh = new THREE.Mesh(crownGeo, crownMat);
      crownMesh.rotation.x = Math.PI / 2;
      crownMesh.position.y = 0.85;
      stageGroup.add(crownMesh);

      scene.add(stageGroup);
      stageGroupsRef.current[spec.name] = stageGroup;
    });

    // --- Pipeline Register Partitions (Latches between stages) ---
    const latchPositions = [-7.15, -2.4, 2.4, 7.15];
    latchPositions.forEach((lx) => {
      const latchGeo = new THREE.BoxGeometry(0.2, 1.8, 6.0);
      const latchMat = new THREE.MeshPhysicalMaterial({
        color: 0x38bdf8,
        metalness: 0.2,
        roughness: 0.1,
        transparent: true,
        opacity: isSoftwareGl ? 0.4 : 0.6,
      });
      const latch = new THREE.Mesh(latchGeo, latchMat);
      latch.position.set(lx, 1.2, 0);
      scene.add(latch);
    });

    // --- Datapath Bus Cable Ribbon (Main pipeline flow) ---
    const busCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-9.5, 0.6, 2.4),
      new THREE.Vector3(-4.8, 0.6, 2.4),
      new THREE.Vector3(0.0, 0.6, 2.4),
      new THREE.Vector3(4.8, 0.6, 2.4),
      new THREE.Vector3(9.5, 0.6, 2.4),
    ]);
    const busGeo = new THREE.TubeGeometry(busCurve, 32, 0.14, 8, false);
    const busMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.4,
      metalness: 0.8,
      roughness: 0.2,
    });
    const busMesh = new THREE.Mesh(busGeo, busMat);
    scene.add(busMesh);

    // --- Forwarding Bypass Buses (EX/MEM -> EX & MEM/WB -> EX) ---
    const fwdCurve1 = new THREE.CatmullRomCurve3([
      new THREE.Vector3(2.4, 1.5, -2.5),
      new THREE.Vector3(1.2, 2.8, -3.2),
      new THREE.Vector3(0.0, 1.8, -2.5),
    ]);
    const fwdGeo1 = new THREE.TubeGeometry(fwdCurve1, 24, 0.1, 8, false);
    const fwdMat1 = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      emissive: 0x9333ea,
      emissiveIntensity: 0.6,
      metalness: 0.8,
      roughness: 0.2,
    });
    const fwdMesh1 = new THREE.Mesh(fwdGeo1, fwdMat1);
    scene.add(fwdMesh1);

    // WB Loopback Conduit (WB -> ID)
    const wbLoopCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(9.5, 1.0, -3.0),
      new THREE.Vector3(5.0, 3.5, -4.5),
      new THREE.Vector3(-2.0, 3.5, -4.5),
      new THREE.Vector3(-4.8, 1.2, -3.0),
    ]);
    const wbLoopGeo = new THREE.TubeGeometry(wbLoopCurve, 40, 0.08, 8, false);
    const wbLoopMat = new THREE.MeshStandardMaterial({
      color: 0xf472b6,
      emissive: 0xdb2777,
      emissiveIntensity: 0.5,
      metalness: 0.8,
      roughness: 0.3,
    });
    const wbLoopMesh = new THREE.Mesh(wbLoopGeo, wbLoopMat);
    scene.add(wbLoopMesh);

    // Forwarding Pulse Indicator Sphere
    const pulseGeo = new THREE.SphereGeometry(0.35, 16, 16);
    const pulseMat = new THREE.MeshBasicMaterial({ color: 0xec4899 });
    const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
    pulseMesh.visible = false;
    scene.add(pulseMesh);
    forwardingPulseRef.current = pulseMesh;

    // Stall Warning Halo Ring (appears around EX during bubble)
    const haloGeo = new THREE.TorusGeometry(1.8, 0.12, 12, 32);
    const haloMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const haloMesh = new THREE.Mesh(haloGeo, haloMat);
    haloMesh.rotation.x = Math.PI / 2;
    haloMesh.position.set(0, 2.5, 0);
    haloMesh.visible = false;
    scene.add(haloMesh);
    stallHaloRef.current = haloMesh;

    // Animation Loop
    let animId = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      if (controlsRef.current) {
        controlsRef.current.update();
      }

      // Idle float for active instruction indicators
      const time = clock.getElapsedTime();
      if (stallHaloRef.current && stallHaloRef.current.visible) {
        stallHaloRef.current.rotation.z += delta * 1.5;
        stallHaloRef.current.scale.setScalar(1.0 + Math.sin(time * 6) * 0.08);
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container || !camera || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Update 3D visual states whenever currentCycle or snapshot changes
  useEffect(() => {
    if (!snapshot) return;

    // Highlight stages that are currently processing instructions
    const stageNames: ('IF' | 'ID' | 'EX' | 'MEM' | 'WB')[] = ['IF', 'ID', 'EX', 'MEM', 'WB'];
    stageNames.forEach((s) => {
      const group = stageGroupsRef.current[s];
      if (group) {
        const hasInstr = snapshot.stages[s] !== null;
        group.position.y = hasInstr ? 0.55 : 0.4;
      }
    });

    // Check stall halo
    if (stallHaloRef.current) {
      stallHaloRef.current.visible = snapshot.stallOccurred;
    }

    // Check forwarding pulse
    if (forwardingPulseRef.current) {
      if (snapshot.forwardingEvents && snapshot.forwardingEvents.length > 0) {
        forwardingPulseRef.current.visible = true;
        forwardingPulseRef.current.position.set(0, 2.6, -1.8);
      } else {
        forwardingPulseRef.current.visible = false;
      }
    }
  }, [currentCycle, snapshot]);

  // Camera preset handler
  const setCameraPreset = (preset: 'iso' | 'alu' | 'forwarding' | 'top') => {
    setActiveCameraPreset(preset);
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    if (!camera || !controls) return;

    if (preset === 'iso') {
      camera.position.set(0, 14, 24);
      controls.target.set(0, 1.5, 0);
    } else if (preset === 'alu') {
      camera.position.set(0, 6, 8);
      controls.target.set(0, 1.5, 0);
    } else if (preset === 'forwarding') {
      camera.position.set(2, 8, -12);
      controls.target.set(1, 1.5, -2);
    } else if (preset === 'top') {
      camera.position.set(0, 28, 0.1);
      controls.target.set(0, 0, 0);
    }
    controls.update();
  };

  return (
    <div className="relative w-full h-[620px] rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl">
      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Left Minimal Overlay: Active Stage Readout */}
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2 max-w-sm pointer-events-none">
        <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl px-4 py-2.5 backdrop-blur-md shadow-lg">
          <div className="flex items-center justify-between gap-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
              3D Microarchitecture Core
            </span>
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800/60">
              Cycle {currentCycle} / {simResult.totalCycles}
            </span>
          </div>

          <div className="mt-2 grid grid-cols-5 gap-1.5 text-center text-[10px] font-mono">
            {(['IF', 'ID', 'EX', 'MEM', 'WB'] as const).map((stage) => {
              const state = snapshot?.stages[stage];
              const isOccupied = state !== null;
              return (
                <div
                  key={stage}
                  className={`py-1 rounded border transition-colors ${
                    isOccupied
                      ? 'bg-cyan-950/70 text-cyan-200 border-cyan-500/60 font-semibold'
                      : 'bg-slate-950/40 text-slate-500 border-slate-800'
                  }`}
                >
                  <div>{stage}</div>
                  <div className="truncate text-[9px] px-0.5">
                    {state ? state.mnemonic.split(' ')[0] : 'idle'}
                  </div>
                </div>
              );
            })}
          </div>

          {snapshot?.stallOccurred && (
            <div className="mt-2 text-[11px] font-medium text-rose-300 bg-rose-950/60 border border-rose-800/80 rounded px-2 py-1">
              ⚠ STALL BUBBLE: {snapshot.stallReason || 'Pipeline Hazard'}
            </div>
          )}

          {snapshot?.forwardingEvents && snapshot.forwardingEvents.length > 0 && (
            <div className="mt-1 text-[11px] font-medium text-fuchsia-300 bg-fuchsia-950/60 border border-fuchsia-800/80 rounded px-2 py-1">
              ⚡ FORWARDING ACTIVE: {snapshot.forwardingEvents[0].description}
            </div>
          )}
        </div>
      </div>

      {/* Collapsible Bottom Control Dock */}
      <div
        className={`absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-3xl transition-transform duration-300 ease-in-out ${
          isDockCollapsed ? 'translate-y-[calc(100%-28px)]' : 'translate-y-0'
        }`}
      >
        {/* Toggle Bar */}
        <div className="flex justify-center -mb-px">
          <button
            onClick={() => setIsDockCollapsed(!isDockCollapsed)}
            className="bg-slate-900 border border-b-0 border-slate-700 hover:border-cyan-500 text-slate-300 hover:text-white px-4 py-1 rounded-t-lg text-xs font-medium transition-colors shadow-md flex items-center gap-1.5"
          >
            <span>{isDockCollapsed ? '▴ Show 3D Core Controls' : '▾ Hide Controls (Zen Mode)'}</span>
          </button>
        </div>

        {/* Dock Body */}
        <div className="bg-slate-900/95 border border-slate-700 rounded-xl p-3 shadow-2xl backdrop-blur-md flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Cycle Playback Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={onReset}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              title="Reset to Cycle 1"
            >
              Reset
            </button>
            <button
              onClick={onStepBackward}
              disabled={currentCycle <= 1}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-semibold transition"
              title="Step Backward"
            >
              ◀ Step
            </button>
            <button
              onClick={onTogglePlay}
              className={`px-4 py-1.5 rounded-lg font-bold text-xs transition ${
                isPlaying
                  ? 'bg-amber-600 hover:bg-amber-500 text-white'
                  : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-900/40'
              }`}
            >
              {isPlaying ? 'Pause ❚❚' : 'Play Simulation ▶'}
            </button>
            <button
              onClick={onStepForward}
              disabled={currentCycle >= simResult.totalCycles}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-semibold transition"
              title="Step Forward"
            >
              Step ▶
            </button>
          </div>

          {/* Cycle Slider */}
          <div className="flex items-center gap-2 w-full md:w-56">
            <input
              type="range"
              min={1}
              max={Math.max(1, simResult.totalCycles)}
              value={currentCycle}
              onChange={(e) => onSetCycle(parseInt(e.target.value, 10))}
              className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <span className="text-xs font-mono font-bold text-slate-300 w-12 text-right">
              {currentCycle}/{simResult.totalCycles}
            </span>
          </div>

          {/* Camera View Angle Presets */}
          <div className="flex items-center gap-1 border-t md:border-t-0 md:border-l border-slate-700 pt-2 md:pt-0 md:pl-3">
            <span className="text-[11px] text-slate-400 font-medium mr-1">Camera:</span>
            {[
              { id: 'iso', label: 'Isometric' },
              { id: 'alu', label: 'ALU' },
              { id: 'forwarding', label: 'Bypass' },
              { id: 'top', label: 'Top' },
            ].map((cam) => (
              <button
                key={cam.id}
                onClick={() => setCameraPreset(cam.id as any)}
                className={`px-2 py-1 rounded text-xs font-medium transition ${
                  activeCameraPreset === cam.id
                    ? 'bg-cyan-600 text-white'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                {cam.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CycleSnapshot, SimulationResult, StageName } from '../types/riscv.ts';
import { X_TO_ABI } from '../simulator/parser.ts';

interface SimulatorViewProps {
  simResult: SimulationResult;
  currentCycle: number;
  onSetCycle: (cycle: number) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStepForward: () => void;
  onStepBackward: () => void;
  onReset: () => void;
  forwardingEnabled: boolean;
  onToggleForwarding: (val: boolean) => void;
}

const STAGE_COLORS: Record<StageName | 'STALL', { bg: string; text: string; border: string }> = {
  IF: { bg: 'bg-sky-500/20', text: 'text-sky-300', border: 'border-sky-500/50' },
  ID: { bg: 'bg-indigo-500/20', text: 'text-indigo-300', border: 'border-indigo-500/50' },
  EX: { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-500/50' },
  MEM: { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/50' },
  WB: { bg: 'bg-pink-500/20', text: 'text-pink-300', border: 'border-pink-500/50' },
  STALL: { bg: 'bg-rose-500/30', text: 'text-rose-200 font-bold', border: 'border-rose-500/80' },
};

export const SimulatorView: React.FC<SimulatorViewProps> = ({
  simResult,
  currentCycle,
  onSetCycle,
  isPlaying,
  onTogglePlay,
  onStepForward,
  onStepBackward,
  onReset,
  forwardingEnabled,
  onToggleForwarding,
}) => {
  const snapshot: CycleSnapshot | undefined = simResult.cycleSnapshots[currentCycle - 1];

  return (
    <div className="space-y-6">
      {/* Simulation Header & Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col lg:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-bold text-white tracking-tight">Cycle-by-Cycle Pipeline Simulator</h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800/80">
              5-Stage RISC-V Core
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Simulate Harvard architecture pipeline timing, RAW hazard stalls, and forwarding bypass paths.
          </p>
        </div>

        {/* Configuration: Forwarding Toggle */}
        <div className="flex items-center gap-3 bg-slate-950/80 border border-slate-800 px-4 py-2 rounded-xl">
          <span className="text-xs font-semibold text-slate-300">Data Forwarding:</span>
          <button
            onClick={() => onToggleForwarding(!forwardingEnabled)}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              forwardingEnabled
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/30'
                : 'bg-amber-700 text-white shadow-md shadow-amber-900/30'
            }`}
          >
            <span>{forwardingEnabled ? '✓ Enabled (Bypassing)' : '✕ Disabled (Stall-on-RAW)'}</span>
          </button>
        </div>
      </div>

      {/* Cycle Playback Toolbar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onReset}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Reset
          </button>
          <button
            onClick={onStepBackward}
            disabled={currentCycle <= 1}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300 text-xs font-semibold transition"
          >
            ◀ Previous Cycle
          </button>
          <button
            onClick={onTogglePlay}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition ${
              isPlaying
                ? 'bg-amber-600 hover:bg-amber-500 text-white'
                : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-900/40'
            }`}
          >
            {isPlaying ? 'Pause ❚❚' : 'Play ▶'}
          </button>
          <button
            onClick={onStepForward}
            disabled={currentCycle >= simResult.totalCycles}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300 text-xs font-semibold transition"
          >
            Next Cycle ▶
          </button>
        </div>

        {/* Current cycle indicator */}
        <div className="flex items-center gap-3">
          <span className="text-xs text-slate-400">Current Cycle:</span>
          <span className="text-base font-mono font-bold text-cyan-400 bg-cyan-950/80 border border-cyan-800 px-3 py-0.5 rounded-md">
            Cycle {currentCycle} of {simResult.totalCycles}
          </span>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-2 text-[11px] font-medium text-slate-300 flex-wrap">
          <span className="text-slate-400">Legend:</span>
          {(['IF', 'ID', 'EX', 'MEM', 'WB', 'STALL'] as const).map((stage) => {
            const c = STAGE_COLORS[stage];
            return (
              <span
                key={stage}
                className={`px-2 py-0.5 rounded border text-[10px] font-mono font-bold ${c.bg} ${c.text} ${c.border}`}
              >
                {stage === 'STALL' ? 'STALL (Bubble)' : stage}
              </span>
            );
          })}
        </div>
      </div>

      {/* Space-Time Pipeline Execution Matrix (Grid) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
            Pipeline Execution Timing Table (Space-Time Matrix)
          </h3>
          <span className="text-xs text-slate-500">
            Click any column header to jump to that clock cycle
          </span>
        </div>

        <div className="overflow-x-auto border border-slate-800 rounded-xl">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="bg-slate-950/90 border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3 sticky left-0 z-20 bg-slate-950 min-w-[200px] border-r border-slate-800">
                  Instruction
                </th>
                {Array.from({ length: simResult.totalCycles }).map((_, cIdx) => {
                  const cycleNum = cIdx + 1;
                  const isCurrent = cycleNum === currentCycle;
                  return (
                    <th
                      key={cycleNum}
                      onClick={() => onSetCycle(cycleNum)}
                      className={`py-2 px-2 text-center min-w-[42px] cursor-pointer hover:bg-slate-800/80 transition-colors ${
                        isCurrent
                          ? 'bg-cyan-500/20 text-cyan-300 font-bold border-b-2 border-cyan-400'
                          : 'border-r border-slate-800/60'
                      }`}
                    >
                      C{cycleNum}
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {simResult.instructions.map((instr, iIdx) => {
                return (
                  <tr
                    key={instr.id}
                    className="border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors"
                  >
                    {/* Instruction Name / Code */}
                    <td className="py-2 px-3 sticky left-0 z-10 bg-slate-900 font-mono text-slate-200 border-r border-slate-800 whitespace-nowrap">
                      <span className="text-slate-500 mr-2 text-[10px]">I{instr.id}</span>
                      <span className="font-semibold text-slate-100">{instr.mnemonic}</span>{' '}
                      <span className="text-slate-400">
                        {instr.originalText.substring(instr.mnemonic.length).trim()}
                      </span>
                    </td>

                    {/* Cycle Columns */}
                    {Array.from({ length: simResult.totalCycles }).map((_, cIdx) => {
                      const cycleNum = cIdx + 1;
                      const stage = simResult.spaceTimeGrid[iIdx]?.[cIdx];
                      const isCurrent = cycleNum === currentCycle;

                      if (!stage) {
                        return (
                          <td
                            key={cycleNum}
                            className={`py-2 px-1 text-center border-r border-slate-800/30 ${
                              isCurrent ? 'bg-cyan-950/20' : ''
                            }`}
                          >
                            <span className="text-slate-700">-</span>
                          </td>
                        );
                      }

                      const colors = STAGE_COLORS[stage];

                      return (
                        <td
                          key={cycleNum}
                          onClick={() => onSetCycle(cycleNum)}
                          className={`py-1.5 px-1 text-center cursor-pointer border-r border-slate-800/30 transition-all ${
                            isCurrent ? 'ring-2 ring-cyan-400 ring-inset' : ''
                          }`}
                        >
                          <span
                            className={`inline-block w-8 py-0.5 rounded text-[10px] font-bold border ${colors.bg} ${colors.text} ${colors.border}`}
                          >
                            {stage === 'STALL' ? '⚡' : stage}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Active Pipeline Stage Breakdown at Current Cycle */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {(['IF', 'ID', 'EX', 'MEM', 'WB'] as const).map((stage) => {
          const state = snapshot?.stages[stage];
          const colors = STAGE_COLORS[stage];

          return (
            <div
              key={stage}
              className={`rounded-xl border p-4 transition-all ${
                state
                  ? `${colors.bg} ${colors.border} shadow-lg shadow-slate-950/40`
                  : 'bg-slate-900/50 border-slate-800/70 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-xs font-bold uppercase tracking-wider ${colors.text}`}>
                  Stage {stage}
                </span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold ${
                    state ? 'bg-slate-900 text-slate-200' : 'bg-slate-950 text-slate-600'
                  }`}
                >
                  {state ? 'ACTIVE' : 'IDLE'}
                </span>
              </div>

              <div className="mt-2 min-h-[50px]">
                {state ? (
                  <div>
                    <div className="text-xs font-mono font-bold text-white truncate">
                      {state.mnemonic}
                    </div>
                    {state.registerWritten && (
                      <div className="text-[11px] text-slate-300 mt-1">
                        Writes: <span className="font-mono text-cyan-400 font-bold">{X_TO_ABI[state.registerWritten] || state.registerWritten}</span>
                      </div>
                    )}
                    {state.registersRead && state.registersRead.length > 0 && (
                      <div className="text-[11px] text-slate-400">
                        Reads: {state.registersRead.map(r => X_TO_ABI[r] || r).join(', ')}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-xs text-slate-500 italic py-2">No instruction in this stage</div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Architectural Register State Inspector at Current Cycle */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-3">
          Architectural Register File State (Cycle {currentCycle})
        </h3>
        <div className="grid grid-cols-4 sm:grid-cols-8 md:grid-cols-16 gap-2 font-mono text-xs">
          {Array.from({ length: 16 }).map((_, rIdx) => {
            const regName = `x${rIdx}`;
            const abi = X_TO_ABI[regName] || regName;
            const val = snapshot?.registerState[regName] || 0;
            const isNonZero = val !== 0;

            return (
              <div
                key={regName}
                className={`p-2 rounded-lg border text-center transition ${
                  isNonZero
                    ? 'bg-cyan-950/60 border-cyan-700/80 text-cyan-200 font-bold'
                    : 'bg-slate-950/50 border-slate-800/80 text-slate-400'
                }`}
              >
                <div className="text-[10px] text-slate-500">{abi}</div>
                <div className="text-xs font-bold truncate mt-0.5">{val}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

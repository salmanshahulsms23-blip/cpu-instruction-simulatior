/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { LEARNING_TOPICS, LearningTopic } from '../data/learningTopics.ts';

export const LearningCenterView: React.FC = () => {
  const [selectedTopicId, setSelectedTopicId] = useState<string>(LEARNING_TOPICS[0].id);

  // Interactive Micro-Demonstrator state
  const [demoOp1, setDemoOp1] = useState<'alu' | 'load'>('alu');
  const [demoForwarding, setDemoForwarding] = useState<boolean>(true);
  const [demoDistance, setDemoDistance] = useState<number>(1);

  const selectedTopic: LearningTopic =
    LEARNING_TOPICS.find((t) => t.id === selectedTopicId) || LEARNING_TOPICS[0];

  // Calculate stalls for interactive widget
  let calculatedStalls = 0;
  let explanation = '';

  if (!demoForwarding) {
    if (demoDistance === 1) {
      calculatedStalls = 2;
      explanation = 'Distance = 1 cycle. Consumer in ID must wait 2 cycles for producer in EX to reach WB.';
    } else if (demoDistance === 2) {
      calculatedStalls = 1;
      explanation = 'Distance = 2 cycles. Consumer in ID waits 1 cycle for producer in MEM to reach WB.';
    } else {
      calculatedStalls = 0;
      explanation = 'Distance >= 3 cycles. Producer has reached WB; register file already holds new data.';
    }
  } else {
    // With forwarding
    if (demoOp1 === 'load' && demoDistance === 1) {
      calculatedStalls = 1;
      explanation = 'Load-Use Hazard! Data is only ready at end of MEM stage. 1 stall cycle is unavoidable even with forwarding.';
    } else {
      calculatedStalls = 0;
      explanation = 'Bypassing active! Forwarding multiplexers route data directly from EX/MEM or MEM/WB to ALU with 0 stalls.';
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white tracking-tight">Computer Architecture Learning Center</h2>
        <p className="text-sm text-slate-400 mt-1">
          Master the foundational concepts of modern RISC processor design, 5-stage pipelining, hazards, and instruction scheduling with intuitive analogies and technical rigor.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Topic Navigation Sidebar */}
        <div className="lg:col-span-1 space-y-1.5 bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-xl">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-3 py-1 block">
            Topics
          </span>
          {LEARNING_TOPICS.map((topic) => {
            const isSelected = topic.id === selectedTopicId;
            return (
              <button
                key={topic.id}
                onClick={() => setSelectedTopicId(topic.id)}
                className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-medium transition flex items-center justify-between ${
                  isSelected
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white font-bold shadow-md'
                    : 'text-slate-300 hover:bg-slate-800/80'
                }`}
              >
                <span className="truncate">{topic.title}</span>
                <span className="text-[10px] opacity-70">➔</span>
              </button>
            );
          })}
        </div>

        {/* Main Article Content */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                Architecture Article
              </span>
              <h3 className="text-2xl font-bold text-white tracking-tight mt-1">
                {selectedTopic.title}
              </h3>
              <p className="text-sm font-medium text-slate-300 mt-0.5">{selectedTopic.subtitle}</p>
            </div>

            {/* Analogy Card */}
            <div className="bg-amber-950/30 border border-amber-800/60 rounded-xl p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300 uppercase tracking-wider">
                <span>💡</span>
                <span>Everyday Analogy (Intuitive Picture)</span>
              </div>
              <p className="text-xs text-amber-100/90 leading-relaxed font-sans">
                {selectedTopic.analogy}
              </p>
            </div>

            {/* Technical Definition */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider">
                <span>🎓</span>
                <span>Formal Technical Definition</span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed font-sans">
                {selectedTopic.technicalDefinition}
              </p>
            </div>

            {/* Key Points */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Key Architectural Concepts:
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300 font-sans">
                {selectedTopic.keyPoints.map((pt, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span>{pt}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Formula (if present) */}
            {selectedTopic.formula && (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Mathematical Formulation:
                </span>
                <code className="text-xs font-mono font-bold text-indigo-300 block">
                  {selectedTopic.formula}
                </code>
              </div>
            )}

            {/* ASCII Diagram (if present) */}
            {selectedTopic.diagramAscii && (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto">
                <pre className="font-mono text-[11px] text-cyan-300 leading-tight">
                  {selectedTopic.diagramAscii}
                </pre>
              </div>
            )}

            {/* Concrete Example */}
            <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1">
              <span className="font-semibold text-white block">Concrete Example:</span>
              <p className="leading-relaxed">{selectedTopic.example}</p>
            </div>
          </div>

          {/* Interactive Micro-Demonstrator: Hazard & Stall Sandbox */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-base">🧪</span>
              <h3 className="text-base font-bold text-white">Interactive Hazard & Stall Sandbox</h3>
            </div>
            <p className="text-xs text-slate-400">
              Experiment with instruction types, forwarding settings, and instruction distance to see how the CPU hardware handles data dependencies.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div>
                <label className="block text-slate-400 font-medium mb-1.5">Producer Instruction:</label>
                <div className="flex gap-1">
                  <button
                    onClick={() => setDemoOp1('alu')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                      demoOp1 === 'alu'
                        ? 'bg-cyan-600 text-white'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    ALU (add)
                  </button>
                  <button
                    onClick={() => setDemoOp1('load')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                      demoOp1 === 'load'
                        ? 'bg-cyan-600 text-white'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    Load (lw)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1.5">Forwarding Circuit:</label>
                <div className="flex gap-1">
                  <button
                    onClick={() => setDemoForwarding(true)}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                      demoForwarding
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    Enabled
                  </button>
                  <button
                    onClick={() => setDemoForwarding(false)}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                      !demoForwarding
                        ? 'bg-rose-700 text-white'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    Disabled
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1.5">Instruction Distance:</label>
                <div className="flex gap-1">
                  {[1, 2, 3].map((d) => (
                    <button
                      key={d}
                      onClick={() => setDemoDistance(d)}
                      className={`px-3 py-1.5 rounded-lg font-semibold font-mono transition ${
                        demoDistance === d
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {d} {d === 1 ? 'cycle' : 'cycles'}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Sandbox Result Output */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs text-slate-400">Resulting Pipeline Stalls:</span>
                <div className="text-2xl font-mono font-bold text-white flex items-center gap-2">
                  <span className={calculatedStalls > 0 ? 'text-rose-400' : 'text-emerald-400'}>
                    {calculatedStalls} Stall Cycle(s)
                  </span>
                  {calculatedStalls === 0 && (
                    <span className="text-xs font-sans text-emerald-400 font-normal">
                      (Perfect flow, 0 bubbles)
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-300 mt-1">{explanation}</div>
              </div>

              <div className="text-xs font-mono bg-slate-900 border border-slate-800 p-3 rounded-lg text-slate-300">
                <div>I1: {demoOp1 === 'alu' ? 'add t0, t1, t2' : 'lw t0, 0(s0)'}</div>
                {demoDistance > 1 && <div className="text-slate-500">... [independent instructions]</div>}
                <div>I{demoDistance + 1}: add t3, t0, t4</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

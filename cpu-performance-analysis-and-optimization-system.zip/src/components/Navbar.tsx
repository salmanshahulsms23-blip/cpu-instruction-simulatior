/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

export type ViewMode =
  | 'dashboard'
  | 'library'
  | 'simulator'
  | '3d'
  | 'performance'
  | 'bottlenecks'
  | 'optimization'
  | 'learning'
  | 'tests'
  | 'reports';

interface NavbarProps {
  activeView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  onOpenAdvisor: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  forwardingEnabled: boolean;
  onToggleForwarding: (val: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  onSelectView,
  onOpenAdvisor,
  isDark,
  onToggleTheme,
  forwardingEnabled,
  onToggleForwarding,
}) => {
  const navItems: { id: ViewMode; label: string; icon: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: '🏠' },
    { id: 'library', label: 'Programs', icon: '📜' },
    { id: 'simulator', label: 'Pipeline Sim', icon: '⏱️' },
    { id: '3d', label: '3D Core', icon: '🧊' },
    { id: 'performance', label: 'Performance', icon: '📊' },
    { id: 'bottlenecks', label: 'Bottlenecks', icon: '🔍' },
    { id: 'optimization', label: 'Optimization', icon: '⚡' },
    { id: 'learning', label: 'Learning Center', icon: '📚' },
    { id: 'tests', label: 'Verification', icon: '🔬' },
    { id: 'reports', label: 'Reports', icon: '📑' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/95 border-b border-slate-800 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16 gap-3">
        {/* Brand */}
        <div
          onClick={() => onSelectView('dashboard')}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-cyan-950 text-white font-extrabold text-sm group-hover:scale-105 transition-transform">
            CPU
          </div>
          <div className="hidden sm:block">
            <div className="text-sm font-extrabold text-white tracking-tight flex items-center gap-1.5">
              <span>CPU Simulator</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800/80">
                RV32I
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Performance & Optimization</div>
          </div>
        </div>

        {/* Desktop Navigation Tabs */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-900/80 border border-slate-800 p-1 rounded-xl">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-950'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <span className="text-xs">{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* Forwarding Quick Toggle */}
          <button
            onClick={() => onToggleForwarding(!forwardingEnabled)}
            className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition border ${
              forwardingEnabled
                ? 'bg-emerald-950/80 border-emerald-800 text-emerald-300'
                : 'bg-amber-950/80 border-amber-800 text-amber-300'
            }`}
            title="Toggle hardware data forwarding"
          >
            <span className="w-2 h-2 rounded-full bg-current" />
            <span>Fwd: {forwardingEnabled ? 'ON' : 'OFF'}</span>
          </button>

          {/* AI Advisor Button */}
          <button
            onClick={onOpenAdvisor}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-purple-950 transition flex items-center gap-1.5"
            title="Ask Deep Architecture Advisor (gemini-4-argon with High Thinking)"
          >
            <span>✨ AI Advisor</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white flex items-center justify-center text-sm transition"
            title="Toggle Dark / Light Visual Theme"
          >
            {isDark ? '🌙' : '☀️'}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Scrollbar */}
      <div className="lg:hidden flex items-center gap-1.5 px-4 py-2 border-t border-slate-800/80 overflow-x-auto text-xs bg-slate-950">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onSelectView(item.id)}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition ${
              activeView === item.id
                ? 'bg-cyan-600 text-white font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {item.icon} {item.label}
          </button>
        ))}
      </div>
    </header>
  );
};

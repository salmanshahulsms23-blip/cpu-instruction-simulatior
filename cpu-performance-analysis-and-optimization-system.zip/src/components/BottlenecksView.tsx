/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BottleneckItem, SimulationResult } from '../types/riscv.ts';

interface BottlenecksViewProps {
  bottlenecks: BottleneckItem[];
  simResult: SimulationResult;
  onNavigateToOptimization: () => void;
}

export const BottlenecksView: React.FC<BottlenecksViewProps> = ({
  bottlenecks,
  simResult,
  onNavigateToOptimization,
}) => {
  const [filterSeverity, setFilterSeverity] = useState<'all' | 'high' | 'medium' | 'low'>('all');

  const filtered = bottlenecks.filter((b) => {
    if (filterSeverity === 'all') return true;
    if (filterSeverity === 'high') return b.severity === 'high';
    if (filterSeverity === 'medium') return b.severity === 'medium';
    if (filterSeverity === 'low') return b.severity === 'low' || b.severity === 'info';
    return true;
  });

  const highCount = bottlenecks.filter((b) => b.severity === 'high').length;
  const mediumCount = bottlenecks.filter((b) => b.severity === 'medium').length;
  const totalStalls = simResult.stallCycles;

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-bold text-white tracking-tight">CPU Bottleneck Detection Engine</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-950 text-rose-300 border border-rose-800">
                {bottlenecks.length} Issue(s) Diagnosed
              </span>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              Automated detection of Read-After-Write (RAW) data hazards, load-use bubbles, redundant register writes, and scheduling inefficiencies.
            </p>
          </div>

          <button
            onClick={onNavigateToOptimization}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-cyan-900/40 transition flex items-center gap-2 self-start md:self-auto"
          >
            <span>Run Automated Optimizations</span>
            <span>➔</span>
          </button>
        </div>

        {/* Severity Summary Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
          <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-xl">
            <span className="text-xs text-slate-400">Total Hazards</span>
            <div className="text-xl font-bold font-mono text-white mt-1">{bottlenecks.length}</div>
          </div>
          <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-xl">
            <span className="text-xs text-rose-400">High Severity Stalls</span>
            <div className="text-xl font-bold font-mono text-rose-400 mt-1">{highCount}</div>
          </div>
          <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-xl">
            <span className="text-xs text-amber-400">Scheduling Opportunities</span>
            <div className="text-xl font-bold font-mono text-amber-400 mt-1">{mediumCount}</div>
          </div>
          <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-xl">
            <span className="text-xs text-cyan-400">Stall Bubbles Incurred</span>
            <div className="text-xl font-bold font-mono text-cyan-400 mt-1">{totalStalls}</div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <span className="text-xs font-medium text-slate-400 mr-2">Filter by Severity:</span>
        {[
          { id: 'all', label: `All (${bottlenecks.length})` },
          { id: 'high', label: `High Severity (${highCount})` },
          { id: 'medium', label: `Medium (${mediumCount})` },
          { id: 'low', label: `Low / Info` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterSeverity(tab.id as any)}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
              filterSeverity === tab.id
                ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Bottlenecks List */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
            <div className="text-3xl mb-2">🎉</div>
            <div className="text-base font-semibold text-white">No bottlenecks found for this filter</div>
            <p className="text-xs text-slate-500 mt-1">
              Your instruction stream has no critical hazards in this category.
            </p>
          </div>
        ) : (
          filtered.map((item) => {
            const isHigh = item.severity === 'high';
            const isMedium = item.severity === 'medium';

            const severityBadge = isHigh
              ? 'bg-rose-950/80 text-rose-300 border-rose-800'
              : isMedium
              ? 'bg-amber-950/80 text-amber-300 border-amber-800'
              : 'bg-cyan-950/80 text-cyan-300 border-cyan-800';

            return (
              <div
                key={item.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 transition hover:border-slate-700"
              >
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`px-2.5 py-0.5 rounded text-xs font-bold uppercase tracking-wider border ${severityBadge}`}>
                      {item.severity}
                    </span>
                    <h3 className="text-base font-bold text-white">{item.title}</h3>
                  </div>

                  <div className="flex items-center gap-2">
                    {item.isSafeToApply && (
                      <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        ✓ Safe to Optimize
                      </span>
                    )}
                  </div>
                </div>

                {/* Instructions Involved */}
                {item.instructionsInvolved.length > 0 && (
                  <div className="flex items-center gap-2 flex-wrap text-xs">
                    <span className="text-slate-400 font-medium">Instructions Involved:</span>
                    {item.instructionsInvolved.map((id) => {
                      const instr = simResult.instructions.find((i) => i.id === id);
                      return (
                        <span
                          key={id}
                          className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 font-mono text-cyan-300"
                        >
                          I{id}: {instr?.originalText || `Instruction ${id}`}
                        </span>
                      );
                    })}
                  </div>
                )}

                {/* Dual Explanation Grid: Technical vs Beginner */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Technical Explanation */}
                  <div className="bg-slate-950/60 border border-slate-800/80 p-4 rounded-xl">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-400 mb-2">
                      <span>🎓</span>
                      <span>Technical Explanation</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed font-sans">
                      {item.technicalExplanation}
                    </p>
                  </div>

                  {/* Beginner Explanation */}
                  <div className="bg-slate-950/60 border border-slate-800/80 p-4 rounded-xl">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
                      <span>💡</span>
                      <span>Beginner-Friendly Explanation</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed font-sans">
                      {item.beginnerExplanation}
                    </p>
                  </div>
                </div>

                {/* Impact & Improvement Suggestion */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                  <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/60">
                    <span className="font-semibold text-rose-400 block mb-1">Performance Impact:</span>
                    <span className="text-slate-300">{item.impact}</span>
                  </div>

                  <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/60">
                    <span className="font-semibold text-emerald-400 block mb-1">How to Improve:</span>
                    <span className="text-slate-300">{item.improvementSuggestion}</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

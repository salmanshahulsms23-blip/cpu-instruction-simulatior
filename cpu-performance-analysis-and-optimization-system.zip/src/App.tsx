/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useState } from 'react';
import { AdvisorModal } from './components/AdvisorModal.tsx';
import { BottlenecksView } from './components/BottlenecksView.tsx';
import { DashboardView, HistoryItem } from './components/DashboardView.tsx';
import { LearningCenterView } from './components/LearningCenterView.tsx';
import { Navbar, ViewMode } from './components/Navbar.tsx';
import { OptimizationView } from './components/OptimizationView.tsx';
import { PerformanceView } from './components/PerformanceView.tsx';
import { Pipeline3DView } from './components/Pipeline3DView.tsx';
import { ProgramLibraryView } from './components/ProgramLibraryView.tsx';
import { ReportsView } from './components/ReportsView.tsx';
import { SimulatorView } from './components/SimulatorView.tsx';
import { TestSuiteView } from './components/TestSuiteView.tsx';
import { SAMPLE_PROGRAMS } from './data/samplePrograms.ts';
import { detectBottlenecks } from './simulator/bottlenecks.ts';
import { generateOptimizations } from './simulator/optimizer.ts';
import { parseAssembly } from './simulator/parser.ts';
import { simulatePipeline } from './simulator/pipeline.ts';
import { SampleProgram } from './types/riscv.ts';

export default function App() {
  const [activeView, setActiveView] = useState<ViewMode>('dashboard');
  const [currentProgramName, setCurrentProgramName] = useState<string>(SAMPLE_PROGRAMS[3].name);
  const [currentAssembly, setCurrentAssembly] = useState<string>(SAMPLE_PROGRAMS[3].assembly);
  const [forwardingEnabled, setForwardingEnabled] = useState<boolean>(true);
  const [clockFrequencyMHz, setClockFrequencyMHz] = useState<number>(1000);

  // Playback state
  const [currentCycle, setCurrentCycle] = useState<number>(1);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Theme & Advisor modal state
  const [isDark, setIsDark] = useState<boolean>(true);
  const [advisorOpen, setAdvisorOpen] = useState<boolean>(false);

  // History & metrics tracking
  const [totalSimulations, setTotalSimulations] = useState<number>(1);
  const [history, setHistory] = useState<HistoryItem[]>([
    {
      id: 'init-1',
      programName: SAMPLE_PROGRAMS[3].name,
      totalCycles: 9,
      instructionCount: 5,
      cpi: 1.8,
      stallCycles: 1,
      forwardingEnabled: true,
      timestamp: 'Just now',
    },
  ]);

  // Parse assembly
  const parseResult = useMemo(() => {
    return parseAssembly(currentAssembly);
  }, [currentAssembly]);

  // Run cycle-accurate pipeline simulation
  const simResult = useMemo(() => {
    const instructions = parseResult.instructions;
    return simulatePipeline(instructions, forwardingEnabled, clockFrequencyMHz, currentProgramName);
  }, [parseResult.instructions, forwardingEnabled, clockFrequencyMHz, currentProgramName]);

  // Bottlenecks
  const bottlenecks = useMemo(() => {
    return detectBottlenecks(parseResult.instructions, simResult);
  }, [parseResult.instructions, simResult]);

  // Optimizations & Before/After comparison
  const optimizationAnalysis = useMemo(() => {
    return generateOptimizations(parseResult.instructions, forwardingEnabled, clockFrequencyMHz);
  }, [parseResult.instructions, forwardingEnabled, clockFrequencyMHz]);

  // Best optimization percentage
  const bestOptimizationPct = optimizationAnalysis.comparison.cycleReductionPct;

  // Ensure currentCycle is within valid range
  useEffect(() => {
    if (currentCycle > simResult.totalCycles && simResult.totalCycles > 0) {
      setCurrentCycle(simResult.totalCycles);
    }
    if (currentCycle < 1) {
      setCurrentCycle(1);
    }
  }, [simResult.totalCycles, currentCycle]);

  // Auto-play timer loop
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setCurrentCycle((prev) => {
        if (prev >= simResult.totalCycles) {
          setIsPlaying(false);
          return prev;
        }
        return prev + 1;
      });
    }, 750);

    return () => clearInterval(interval);
  }, [isPlaying, simResult.totalCycles]);

  // Handlers
  const handleSelectProgram = (prog: SampleProgram) => {
    setCurrentProgramName(prog.name);
    setCurrentAssembly(prog.assembly);
    setForwardingEnabled(prog.defaultForwarding);
    setCurrentCycle(1);
    setIsPlaying(false);
    setTotalSimulations((prev) => prev + 1);

    // Record history
    const parsed = parseAssembly(prog.assembly);
    const sim = simulatePipeline(parsed.instructions, prog.defaultForwarding, clockFrequencyMHz, prog.name);
    setHistory((prev) => [
      {
        id: `sim-${Date.now()}`,
        programName: prog.name,
        totalCycles: sim.totalCycles,
        instructionCount: sim.instructionCount,
        cpi: sim.cpi,
        stallCycles: sim.stallCycles,
        forwardingEnabled: prog.defaultForwarding,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      },
      ...prev.slice(0, 15),
    ]);
  };

  const handleUpdateCustomAssembly = (newCode: string) => {
    setCurrentProgramName('Custom User Program');
    setCurrentAssembly(newCode);
    setCurrentCycle(1);
    setIsPlaying(false);
    setTotalSimulations((prev) => prev + 1);
  };

  const handleApplyOptimizedCode = (optimizedCode: string) => {
    setCurrentProgramName(`${currentProgramName} (Optimized)`);
    setCurrentAssembly(optimizedCode);
    setCurrentCycle(1);
    setIsPlaying(false);
    setActiveView('simulator');
  };

  const handleStepForward = () => {
    if (currentCycle < simResult.totalCycles) {
      setCurrentCycle((prev) => prev + 1);
    }
  };

  const handleStepBackward = () => {
    if (currentCycle > 1) {
      setCurrentCycle((prev) => prev - 1);
    }
  };

  const handleResetCycle = () => {
    setCurrentCycle(1);
    setIsPlaying(false);
  };

  const handleTogglePlay = () => {
    if (currentCycle >= simResult.totalCycles) {
      setCurrentCycle(1);
    }
    setIsPlaying((prev) => !prev);
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-200 ${
        isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      {/* Top Navbar */}
      <Navbar
        activeView={activeView}
        onSelectView={setActiveView}
        onOpenAdvisor={() => setAdvisorOpen(true)}
        isDark={isDark}
        onToggleTheme={() => setIsDark(!isDark)}
        forwardingEnabled={forwardingEnabled}
        onToggleForwarding={(val) => {
          setForwardingEnabled(val);
          setCurrentCycle(1);
        }}
      />

      {/* Main Content Viewport */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-20">
        {activeView === 'dashboard' && (
          <DashboardView
            onNavigate={setActiveView}
            onSelectProgram={handleSelectProgram}
            simResult={simResult}
            history={history}
            totalSimulations={totalSimulations}
            bestOptimizationPct={bestOptimizationPct}
          />
        )}

        {activeView === 'library' && (
          <ProgramLibraryView
            currentAssembly={currentAssembly}
            onSelectProgram={(p) => {
              handleSelectProgram(p);
              setActiveView('simulator');
            }}
            onUpdateCustomAssembly={handleUpdateCustomAssembly}
            onRunAnalysis={() => setActiveView('simulator')}
          />
        )}

        {activeView === 'simulator' && (
          <SimulatorView
            simResult={simResult}
            currentCycle={currentCycle}
            onSetCycle={setCurrentCycle}
            isPlaying={isPlaying}
            onTogglePlay={handleTogglePlay}
            onStepForward={handleStepForward}
            onStepBackward={handleStepBackward}
            onReset={handleResetCycle}
            forwardingEnabled={forwardingEnabled}
            onToggleForwarding={(val) => {
              setForwardingEnabled(val);
              setCurrentCycle(1);
            }}
          />
        )}

        {activeView === '3d' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">
                  3D Silicon Microarchitecture Core
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Real-time procedural 3D model of the 5-stage RISC-V pipelined core, register latches, ALU, and forwarding bypass network.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveView('simulator')}
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition"
                >
                  Switch to 2D Timing Table
                </button>
              </div>
            </div>

            <Pipeline3DView
              simResult={simResult}
              currentCycle={currentCycle}
              onSetCycle={setCurrentCycle}
              isPlaying={isPlaying}
              onTogglePlay={handleTogglePlay}
              onStepForward={handleStepForward}
              onStepBackward={handleStepBackward}
              onReset={handleResetCycle}
            />
          </div>
        )}

        {activeView === 'performance' && (
          <PerformanceView
            simResult={simResult}
            clockFrequencyMHz={clockFrequencyMHz}
            onChangeClockFrequency={setClockFrequencyMHz}
          />
        )}

        {activeView === 'bottlenecks' && (
          <BottlenecksView
            bottlenecks={bottlenecks}
            simResult={simResult}
            onNavigateToOptimization={() => setActiveView('optimization')}
          />
        )}

        {activeView === 'optimization' && (
          <OptimizationView
            optimizationAnalysis={optimizationAnalysis}
            onApplyOptimizedCode={handleApplyOptimizedCode}
          />
        )}

        {activeView === 'learning' && <LearningCenterView />}

        {activeView === 'tests' && <TestSuiteView />}

        {activeView === 'reports' && (
          <ReportsView
            simResult={simResult}
            comparison={optimizationAnalysis.comparison}
            bottlenecks={bottlenecks}
            programName={currentProgramName}
            clockFrequencyMHz={clockFrequencyMHz}
          />
        )}
      </main>

      {/* Deep Architecture Advisor Modal */}
      <AdvisorModal
        isOpen={advisorOpen}
        onClose={() => setAdvisorOpen(false)}
        codeContext={currentAssembly}
      />
    </div>
  );
}

import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
import {GoogleGenAI, ThinkingLevel} from '@google/genai';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      {
        name: 'gemini-advisor-api',
        configureServer(server) {
          server.middlewares.use('/api/gemini/advisor', async (req, res) => {
            if (req.method !== 'POST') {
              res.statusCode = 405;
              res.end(JSON.stringify({ error: 'Method Not Allowed' }));
              return;
            }

            let body = '';
            req.on('data', (chunk) => {
              body += chunk;
            });

            req.on('end', async () => {
              try {
                const parsed = JSON.parse(body || '{}');
                const prompt = parsed.prompt || '';
                const codeContext = parsed.codeContext || '';

                const apiKey = process.env.GEMINI_API_KEY;
                if (!apiKey) {
                  res.statusCode = 200;
                  res.setHeader('Content-Type', 'application/json');
                  res.end(
                    JSON.stringify({
                      response:
                        "Architecture Advisor Rule-Based Insights:\n\nIn a standard 5-stage RISC-V in-order pipeline (IF, ID, EX, MEM, WB):\n1. Back-to-back ALU instructions (e.g., `add t1, t0, t0` followed by `add t2, t1, t0`) experience a Read-After-Write (RAW) data hazard.\n2. Without forwarding, the consumer in ID must stall for 2 cycles until the producer writes back to the register file in WB.\n3. With EX/MEM-to-EX forwarding, the result is bypassed with 0 stall cycles.\n4. For a load instruction (`lw`) followed by an immediate consumer, the data is only ready at the end of MEM, resulting in a mandatory 1-cycle stall bubble. To eliminate this bubble, hoist an independent instruction into the delay slot.",
                    })
                  );
                  return;
                }

                const ai = new GoogleGenAI({
                  apiKey,
                  httpOptions: {
                    headers: {
                      'User-Agent': 'aistudio-build',
                    },
                  },
                });

                const fullPrompt = `The user is studying or analyzing RISC-V 5-stage pipelining in a CPU performance analysis system.
Current Assembly Program Context:
\`\`\`assembly
${codeContext}
\`\`\`

User Question / Query:
${prompt}

Provide a clear, authoritative, and pedagogically rich response. Explain hazards, timing diagrams, CPI impact, or compiler scheduling strategies clearly.`;

                const response = await ai.models.generateContent({
                  model: 'gemini-4-argon',
                  contents: fullPrompt,
                  config: {
                    systemInstruction:
                      'You are an expert Professor of Computer Architecture and Microprocessor Design specializing in RISC-V 32I, five-stage pipelines (IF, ID, EX, MEM, WB), data hazards (RAW, WAR, WAW), forwarding networks, and instruction scheduling.',
                    thinkingConfig: {
                      thinkingLevel: ThinkingLevel.HIGH,
                    },
                  },
                });

                res.statusCode = 200;
                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify({ response: response.text }));
              } catch (err: any) {
                console.error('Gemini advisor error:', err);
                res.statusCode = 200;
                res.setHeader('Content-Type', 'application/json');
                res.end(
                  JSON.stringify({
                    response: `Advisor Response (Offline Mode): For RISC-V 5-stage pipelining, ensure that independent instructions are scheduled between load operations and their consumers to avoid the 1-cycle load-use latency penalty. RAW hazards without forwarding require 2 stall cycles. Details: ${err.message || 'Active simulation rules verified.'}`,
                  })
                );
              }
            });
          });
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
